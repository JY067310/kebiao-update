@echo off
setlocal
chcp 65001 >nul
title reset admin token
cd /d "%~dp0"

rem ASCII only + CRLF, same reason as start.cmd: cmd.exe re-reads batch
rem files by byte offset after chcp 65001, so multi-byte chars here would
rem shift the parser. Chinese output comes from scripts/reset-admin.mjs.

set "NODE="
where node >nul 2>nul && set "NODE=node"
if not defined NODE if exist "%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe" set "NODE=%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
if not defined NODE if exist "%PROGRAMFILES%\nodejs\node.exe" set "NODE=%PROGRAMFILES%\nodejs\node.exe"
if not defined NODE if exist "%PROGRAMFILES(X86)%\nodejs\node.exe" set "NODE=%PROGRAMFILES(X86)%\nodejs\node.exe"

if not defined NODE (
  echo.
  echo   Node.js not found. Run start.cmd once, or install Node.js 22+.
  echo.
  pause
  exit /b 1
)

"%NODE%" "scripts\reset-admin.mjs"
pause
