@echo off
setlocal
chcp 65001 >nul
title app-bridge
cd /d "%~dp0"

rem ============================================================
rem  One-click start. Double-click this file, nothing else needed.
rem  First run installs deps, creates a token, opens the tunnel.
rem
rem  KEEP THIS FILE PURE ASCII WITH CRLF LINE ENDINGS.
rem  cmd.exe re-reads a batch file by byte offset right after
rem  `chcp 65001`, so any multi-byte character in here shifts that
rem  offset and the parser starts executing garbage ("'find_node'
rem  is not recognized..."). All Chinese text is printed by
rem  scripts/launcher.mjs instead; Node handles UTF-8 correctly.
rem ============================================================

:find_node
set "NODE="
where node >nul 2>nul && set "NODE=node"
if not defined NODE if exist "%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe" set "NODE=%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
if not defined NODE if exist "%PROGRAMFILES%\nodejs\node.exe" set "NODE=%PROGRAMFILES%\nodejs\node.exe"
if not defined NODE if exist "%PROGRAMFILES(X86)%\nodejs\node.exe" set "NODE=%PROGRAMFILES(X86)%\nodejs\node.exe"
if defined NODE goto :run

cls
echo.
echo   ==============================================
echo     Node.js not found
echo   ==============================================
echo.
echo   Option 1: install Node.js 22 or newer
echo       https://nodejs.org/zh-cn
echo     then double-click this file again.
echo.
echo   Option 2: install DeepSeek Harness desktop and sign in once.
echo     It ships its own Node runtime, this script will find it.
echo.
pause
exit /b 1

:run
"%NODE%" "scripts\launcher.mjs" %*

rem Stop from the console (or Ctrl+C) is a normal exit.
rem The old version checked stopped.flag BEFORE the exit code, so a real
rem startup error was swallowed and the window closed with no message.
set "RC=%errorlevel%"
if exist "state\stopped.flag" del "state\stopped.flag" >nul 2>nul
if not "%RC%"=="0" (
  echo.
  echo   ----------------------------------------------
  echo     Startup failed. Screenshot the lines above
  echo     and send them to whoever gave you this folder.
  echo   ----------------------------------------------
  echo.
  pause
)
exit /b 0
