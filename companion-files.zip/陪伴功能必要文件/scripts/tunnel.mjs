// app-bridge / scripts/tunnel.mjs
//
// 给本机 HTTP 桥接套一层 Cloudflare quick tunnel（HTTPS）。
//
// 为什么需要：Android release 包禁止明文 HTTP（usesCleartextTraffic=false +
// network_security_config 只放行 jsnu.edu.cn），手机填 http://10.x.x.x 会被系统直接掐掉。
// 换成 https://*.trycloudflare.com 就不用改 App，也不用手机和电脑在同一 WiFi。
//
// 既能被 launcher.mjs 引用，也能单独跑：node scripts/tunnel.mjs

import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const TUNNEL_URL_FILE = path.join(ROOT, 'state', 'tunnel-url.txt');
const TUNNEL_LOG = path.join(ROOT, 'logs', 'tunnel.log');
const URL_RE = /https:\/\/[a-z0-9][a-z0-9-]*\.trycloudflare\.com/i;

/** 优先用项目自带的 cloudflared，找不到再回落到课表项目 / 系统 PATH。 */
export function findCloudflared() {
  const candidates = [
    process.env.CLOUDFLARED,
    path.join(ROOT, 'bin', process.platform === 'win32' ? 'cloudflared.exe' : 'cloudflared'),
    'C:/Users/姜建宇/Desktop/课表/tools/bin/cloudflared.exe',
    'C:/Android/tmp/bin/cloudflared.exe',
    'cloudflared',
  ].filter(Boolean);
  return candidates.find((p) => {
    try { return p === 'cloudflared' || fs.existsSync(p); } catch { return false; }
  }) || null;
}

export function readTunnelUrl() {
  try { return fs.readFileSync(TUNNEL_URL_FILE, 'utf8').trim() || null; } catch { return null; }
}

export function clearTunnelUrl() {
  try { fs.unlinkSync(TUNNEL_URL_FILE); } catch { /* 没有就算了 */ }
}

/**
 * 启动隧道。返回 { child, waitForUrl, stop, url }。
 * 地址会同时写进 state/tunnel-url.txt，状态页和再次运行 start.cmd 时都能读到。
 *
 * 两种模式，由 config.json 的 tunnel.mode 决定：
 *   quick（默认）—— trycloudflare 临时隧道，每次启动地址都变，零配置。
 *   named        —— Cloudflare 命名隧道，地址固定为 tunnel.publicUrl，重启也不变。
 *                   需要先建好隧道并把 token 填进 config.json。
 */
export function startTunnel({ port = 8790, cfg = {} } = {}) {
  const exe = findCloudflared();
  if (!exe) return null;

  fs.mkdirSync(path.dirname(TUNNEL_URL_FILE), { recursive: true });
  fs.mkdirSync(path.dirname(TUNNEL_LOG), { recursive: true });
  clearTunnelUrl();
  // 日志是追加的，不清空会读到上一次那个已经失效的地址
  try { fs.writeFileSync(TUNNEL_LOG, '', 'utf8'); } catch { /* ignore */ }

  const mode = String(cfg?.tunnel?.mode || 'quick').toLowerCase();
  const namedToken = String(cfg?.tunnel?.token || '').trim();
  const fixedUrl = String(cfg?.tunnel?.publicUrl || '').trim().replace(/\/+$/, '');

  if (mode === 'named') {
    if (!namedToken) {
      try {
        fs.writeFileSync(TUNNEL_LOG, '隧道模式是 named，但 config.json 里 tunnel.token 是空的。\n', 'utf8');
      } catch { /* ignore */ }
      return null;
    }

    // token 里已经带着隧道 ID 和云端 ingress 规则，不需要 --url，也不用本地 cert.pem。
    // 参数层级不能搞错：--no-autoupdate / --protocol / --logfile / --loglevel 属于
    // `cloudflared tunnel` 命令级，必须放在 `run` 之前；`--token` 才是 run 子命令的。
    // 以前把 logfile/loglevel 放在 run 后面，cloudflared 会直接报
    // "flag provided but not defined: -loglevel" 并退出。
    const child = spawn(exe, [
      'tunnel', '--no-autoupdate', '--protocol', 'http2',
      '--logfile', TUNNEL_LOG, '--loglevel', 'info',
      'run', '--token', namedToken,
    ], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });

    // cloudflared 有些早期报错只走 stdout/stderr；pipe 没人读会填满并阻塞子进程
    const onNamedData = (d) => {
      try { fs.appendFileSync(TUNNEL_LOG, d.toString()); } catch { /* ignore */ }
    };
    child.stdout?.on('data', onNamedData);
    child.stderr?.on('data', onNamedData);

    const url = fixedUrl || null;
    if (url) fs.writeFileSync(TUNNEL_URL_FILE, url + '\n', 'utf8');

    // 固定地址不用从日志里抓，但等它真的通了再返回，免得手机刚连上就报错。
    // 云端 Public Hostname 还没配好时 health 必然不通，所以超时只要进程还活着就放行。
    const waitForUrl = async (timeoutMs = 30_000) => {
      if (!url) return null;
      const deadline = Date.now() + timeoutMs;
      while (Date.now() < deadline) {
        if (child.exitCode !== null) return null; // 进程挂了就别假装成功
        try {
          const res = await fetch(`${url}/v1/health`, { signal: AbortSignal.timeout(4000) });
          if (res.ok) return url;
        } catch { /* 还没连上，继续等 */ }
        await new Promise((r) => setTimeout(r, 1200));
      }
      return child.exitCode === null ? url : null;
    };

    const stop = () => {
      clearTunnelUrl();
      try { child.kill(); } catch { /* ignore */ }
    };

    return { child, waitForUrl, stop, exe, named: true, get url() { return url; } };
  }

  const child = spawn(exe, [
    'tunnel', '--url', `http://127.0.0.1:${port}`,
    '--no-autoupdate', '--protocol', 'http2',
    '--logfile', TUNNEL_LOG, '--loglevel', 'info',
  ], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });

  let url = null;
  let buffer = '';
  const listeners = new Set();

  function accept(text) {
    if (url) return;
    const m = URL_RE.exec(text);
    if (!m) return;
    url = m[0];
    fs.writeFileSync(TUNNEL_URL_FILE, url + '\n', 'utf8');
    for (const fn of listeners) fn(url);
    listeners.clear();
  }

  const onData = (d) => {
    buffer = (buffer + d.toString()).slice(-8000);
    accept(buffer);
  };
  child.stdout?.on('data', onData);
  child.stderr?.on('data', onData);

  // cloudflared 有时只把地址写进 logfile，兜底轮询
  const timer = setInterval(() => {
    if (url) { clearInterval(timer); return; }
    try { accept(fs.readFileSync(TUNNEL_LOG, 'utf8')); } catch { /* 还没生成 */ }
  }, 700);
  timer.unref?.();

  const waitForUrl = (timeoutMs = 30_000) => new Promise((resolve) => {
    if (url) return resolve(url);
    const t = setTimeout(() => { listeners.delete(fn); resolve(null); }, timeoutMs);
    const fn = (u) => { clearTimeout(t); resolve(u); };
    listeners.add(fn);
    child.once('exit', () => { clearTimeout(t); listeners.delete(fn); resolve(null); });
  });

  const stop = () => {
    clearInterval(timer);
    clearTunnelUrl();
    try { child.kill(); } catch { /* ignore */ }
  };

  return { child, waitForUrl, stop, exe, get url() { return url; } };
}

// 单独运行：把地址打印出来，Ctrl+C 停止
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const port = Number(process.env.APP_BRIDGE_PORT || 8790);
  const t = startTunnel({ port });
  if (!t) { console.error('找不到 cloudflared.exe'); process.exit(1); }
  console.log(`cloudflared: ${t.exe}`);
  console.log('正在建立 HTTPS 隧道…');
  const url = await t.waitForUrl(40_000);
  if (url) console.log(`手机填这个：${url}`);
  else console.log('⚠ 40 秒内没拿到地址，看 logs/tunnel.log');
  const bye = () => { t.stop(); process.exit(0); };
  process.on('SIGINT', bye);
  process.on('SIGTERM', bye);
}
