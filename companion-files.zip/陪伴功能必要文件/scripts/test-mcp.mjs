// 验证 MCP server 能驱动桥接：initialize → tools/list → app_send_message → app_health
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const child = spawn(process.execPath, [path.join(ROOT, 'src', 'mcp-app.mjs')], {
  env: { ...process.env, BOT_BRIDGE_URL: process.env.BOT_BRIDGE_URL || 'http://127.0.0.1:8790', BOT_ADMIN_TOKEN: process.env.BOT_ADMIN_TOKEN || 'change-me-admin' },
  stdio: ['pipe', 'pipe', 'pipe'],
});

let buf = '';
const replies = new Map();
child.stdout.setEncoding('utf8');
child.stdout.on('data', (c) => {
  buf += c;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    try { const m = JSON.parse(line); replies.set(m.id, m); } catch { /* ignore */ }
  }
});
child.stderr.on('data', (d) => process.stderr.write(`[mcp] ${d}`));

const req = (id, method, params) => new Promise((resolve, reject) => {
  child.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
  const t = setInterval(() => {
    if (replies.has(id)) { clearInterval(t); resolve(replies.get(id)); }
  }, 20);
  setTimeout(() => { clearInterval(t); reject(new Error(`超时 ${method}`)); }, 8000);
});

let pass = 0, fail = 0;
const ok = (n, c, extra = '') => { c ? (pass++, console.log(`  ✓ ${n}`)) : (fail++, console.log(`  ✗ ${n} ${extra}`)); };

const init = await req(1, 'initialize', { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 't', version: '0' } });
ok('initialize', init.result?.serverInfo?.name === 'app-bridge', JSON.stringify(init).slice(0, 200));

const list = await req(2, 'tools/list');
ok('三个工具', list.result?.tools?.length === 3, JSON.stringify(list.result?.tools?.map((t) => t.name)));

const health = await req(3, 'tools/call', { name: 'app_health', arguments: {} });
ok('app_health 通', health.result?.content?.[0]?.text?.includes('"ok":true'), JSON.stringify(health).slice(0, 200));

const send = await req(4, 'tools/call', { name: 'app_send_message', arguments: { conversationId: 'u1', text: '（MCP 测试）我没走开，就在这儿。' } });
ok('app_send_message 写入', send.result?.content?.[0]?.text?.includes('"ok":true'), JSON.stringify(send).slice(0, 200));

const bad = await req(5, 'tools/call', { name: 'nope', arguments: {} });
ok('未知工具 isError', bad.result?.isError === true);

child.kill();
console.log(`\n${pass} 通过 / ${fail} 失败`);
process.exit(fail ? 1 : 0);
