// app-bridge / scripts/reset-admin.mjs
//
// 重新生成管理令牌。什么时候用：
//   · 令牌文件删了 / 找不到了
//   · 怀疑令牌被别人看到过，想换一把
// 跑完要重启桥接才生效（config.json 只在启动时读一次）。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CONFIG = path.join(ROOT, 'config.json');
const TOKEN_FILE = path.join(
  process.env.APPDATA || path.join(os.homedir(), '.config'),
  'app-bridge',
  'admin-token.txt',
);

if (!fs.existsSync(CONFIG)) {
  console.error('找不到 config.json，请先双击 start.cmd 跑一次。');
  process.exit(1);
}

const plain = crypto.randomBytes(18).toString('base64url');
const hash = crypto.createHash('sha256').update(plain).digest('hex');

const cfg = JSON.parse(fs.readFileSync(CONFIG, 'utf8'));
cfg.app ||= {};
cfg.app.adminTokenHash = hash;
delete cfg.app.adminToken;              // 明文不再留在项目里
fs.writeFileSync(CONFIG, `${JSON.stringify(cfg, null, 2)}\n`, 'utf8');

fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
fs.writeFileSync(TOKEN_FILE, `${plain}\n`, { encoding: 'utf8', mode: 0o600 });

console.log('');
console.log('  新的管理令牌已生成');
console.log(`  ${plain}`);
console.log('');
console.log(`  同时写到了：${TOKEN_FILE}`);
console.log('  config.json 里只存它的哈希，看不到明文。');
console.log('');
console.log('  下一步：关掉桥接窗口，重新双击 start.cmd，再用这个令牌登录控制台。');
console.log('');
