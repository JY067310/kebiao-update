// 排障：看桥接创建的会话在 DSH 里到底发生了什么
import { NodeApiClient, unwrap } from '../lib/dsh-client.js';

const base = process.env.DSH_WEB_URL || 'http://127.0.0.1:25115';
const client = new NodeApiClient(base, 15000, {});
const sid = process.argv[2];

const list = unwrap(await client.sessions.list({}), 'session.list');
const mine = list.items.filter((s) => String(s.sessionId).startsWith('appb-'));
console.log(`appb-* 会话 ${mine.length} 个`);
for (const s of mine) {
  console.log(`- ${s.sessionId} running=${s.running} blank=${s.blank} cwd=${s.cwd} updated=${new Date(s.updatedAt).toLocaleTimeString()}`);
}

for (const s of mine) {
  try {
    const h = unwrap(await client.sessions.history({ sessionId: s.sessionId, maxMessages: 30 }), 'session.history');
    console.log(`\n=== ${s.sessionId} 事件 ${h.events.length} 条 ===`);
    for (const e of h.events) {
      const ev = e.event ?? e;
      const detail = ev.type === 'assistant/message'
        ? JSON.stringify(ev.data?.message?.content ?? []).slice(0, 160)
        : ev.type === 'user/message' ? JSON.stringify(ev.data?.message?.content ?? ev.data).slice(0, 160) : '';
      console.log(`  ${ev.type} ${detail}`);
    }
  } catch (err) {
    console.log(`history 失败 ${s.sessionId}: ${err.message}`);
  }
}
