// 协议级端到端：直接对 DSH 建会话 → follow → prompt → 打印事件
import { NodeApiClient, unwrap, createTurnCollector } from '../lib/dsh-client.js';

const base = process.env.DSH_WEB_URL || 'http://127.0.0.1:25115';
const client = new NodeApiClient(base, 20000, {});

const created = unwrap(
  await client.sessions.create({ cwd: 'C:\\Users\\姜建宇\\Desktop\\课表\\app-bridge\\.sandbox', agentPreset: 'minimal' }),
  'session.create',
);
console.log('会话', created.sessionId, 'preset', created.agentPreset);

const stream = client.openRemoteEventStream(undefined, () => console.log('[stream] open'));
const collector = createTurnCollector();
let done = false;

const pump = (async () => {
  // 生成器直接 yield envelope：{ rpcId, payload: { type, ... } }
  for await (const envelope of stream) {
    const p = envelope?.payload;
    console.log('[frame]', p?.type ?? JSON.stringify(envelope).slice(0, 160));
    if (p?.type === 'session/event') {
      const ev = p.event;
      console.log('  event', ev.type, JSON.stringify(ev.data ?? {}).slice(0, 120));
      const turn = collector.push(ev);
      if (turn) { console.log('\n[REPLY]', JSON.stringify(turn)); done = true; }
    } else if (p?.type === 'session/snapshot') {
      console.log('[snapshot]', p.sessionId, 'records', p.snapshot?.records?.length ?? 0);
    }
  }
})();

await new Promise((r) => setTimeout(r, 1500));
stream.follow(created.sessionId);
console.log('已 follow，发送 prompt…');

const accepted = await client.sessions.prompt({
  sessionId: created.sessionId,
  mode: 'queue',
  content: [{ type: 'text', text: '用一句话回答：你在吗？' }],
});
console.log('prompt 返回', JSON.stringify(accepted.result ?? accepted).slice(0, 200));

const t0 = Date.now();
while (!done && Date.now() - t0 < 90_000) await new Promise((r) => setTimeout(r, 500));
console.log(done ? '✓ 拿到回复' : '✗ 90 秒内没有 turn/end');

const list = unwrap(await client.sessions.list({}), 'session.list');
const s = list.items.find((x) => x.sessionId === created.sessionId);
console.log('会话状态', JSON.stringify({ running: s?.running, blank: s?.blank, updatedAt: s?.updatedAt }));

process.exit(0);
