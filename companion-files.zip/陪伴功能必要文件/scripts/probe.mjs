// 只读探活：确认本机 DSH 的鉴权与 RPC 形状能被 lib/dsh-client.js 复用。
import { NodeApiClient, discoverDshSessionCookie } from '../lib/dsh-client.js';

const base = process.env.DSH_WEB_URL || 'http://127.0.0.1:25115';
const client = new NodeApiClient(base, 10000, {});

console.log(`基址 ${base}`);
console.log(`有鉴权手段: ${client.hasAuth()}`);
console.log(`离线 Cookie: ${discoverDshSessionCookie(base) ? '可铸造' : '不可用'}`);

for (const method of ['settings/describe', 'session/list', 'agentPresets/list']) {
  try {
    const out = await client.callUnary(method, {});
    const text = JSON.stringify(out).slice(0, 400);
    console.log(`\n[${method}] ok → ${text}…`);
  } catch (e) {
    console.log(`\n[${method}] 失败 → ${e.message}`);
  }
}
