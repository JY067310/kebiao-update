// 停止 app-bridge（被 stop.cmd 调用）：按 pid.json 结束启动器与桥接子进程。
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PID_FILE = path.join(ROOT, 'state', 'pid.json');
const IS_WIN = process.platform === 'win32';

let pid = null;
try { pid = JSON.parse(fs.readFileSync(PID_FILE, 'utf8')); } catch { /* 没在跑 */ }

if (!pid) {
  console.log('没有找到运行记录，可能本来就没在跑。');
  process.exit(0);
}

// 先停启动器（否则它的守护逻辑会立刻把桥接拉起来），再停桥接
const targets = [pid.launcher, pid.bridge].filter(Boolean);

// 留个标记，让 start.cmd 知道「这次是正常停止」而不是启动失败
try {
  fs.mkdirSync(path.dirname(PID_FILE), { recursive: true });
  fs.writeFileSync(path.join(path.dirname(PID_FILE), 'stopped.flag'), String(Date.now()));
} catch { /* ignore */ }

for (const p of targets) {
  try {
    if (IS_WIN) spawnSync('taskkill', ['/PID', String(p), '/T', '/F'], { stdio: 'ignore' });
    else process.kill(p, 'SIGTERM');
    console.log(`已结束进程 ${p}`);
  } catch {
    console.log(`进程 ${p} 已经不在了`);
  }
}

try { fs.unlinkSync(PID_FILE); } catch { /* ignore */ }
console.log('app-bridge 已停止。');
