// app-bridge / scripts/launcher.mjs
//
// 双击 start.cmd 之后跑的启动器。负责小白也能跑起来的那些事：
//   1. 首次运行生成 config.json（随机令牌，不用手填）
//   2. 依赖没装就自动 npm install
//   3. DSH 没开就试着拉起它，并等它起来
//   4. 单实例：已经跑着就只打开状态页，不重复起
//   5. 守护：桥接崩了自动重启；日志写 logs/
//   6. 创建第一个用户的 API 令牌并打印
//   7. --install-startup：添加到开机启动
//   8. --remove-startup：移除开机启动
//   9. 自动开 HTTPS 隧道，打印手机该填的地址（--no-tunnel 可跳过）

import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { startTunnel, readTunnelUrl, clearTunnelUrl } from './tunnel.mjs';
import { initVault, readJson } from '../src/vault.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CONFIG = path.join(ROOT, 'config.json');
const EXAMPLE = path.join(ROOT, 'config.example.json');
const STATE_DIR = path.join(ROOT, 'state');
const LOG_DIR = path.join(ROOT, 'logs');
const PID_FILE = path.join(STATE_DIR, 'pid.json');
const IS_WIN = process.platform === 'win32';
const argv = new Set(process.argv.slice(2));

const log = (...a) => console.log(...a);
const die = (msg, code = 1) => { console.error(`\n✗ ${msg}\n`); process.exit(code); };

// ───────────────────────── --help ─────────────────────────
// 帮助文案放在这里而不是 start.cmd 里：批处理只要出现中文，
// cmd.exe 在 `chcp 65001` 之后按字节偏移重读文件就会错位，
// 把 :label、rem、echo 全当成命令执行（"'find_node' 不是内部或外部命令"）。
// 交给 Node 打印就没有这个坑。
if (argv.has('--help') || argv.has('-h')) {
  log(`
  app-bridge - 手机 App 和你电脑上 AI 之间的桥

  最常用：直接双击 start.cmd

  可加的参数：
    start.cmd --install-startup     加入开机自启（以后开机自动跑）
    start.cmd --remove-startup      取消开机自启
    start.cmd --force               强制重启（已经在跑的时候用）
    start.cmd --no-open             启动后不自动打开浏览器
    start.cmd --no-tunnel           不开公网隧道（只用局域网地址）
    start.cmd --no-dsh              不自动拉起 DeepSeek Harness
    start.cmd --quiet               少打印一些日志

  停止：双击 stop.cmd，或直接关掉这个黑窗口。
`);
  process.exit(0);
}

// ───────────────────────── 开机启动 ─────────────────────────
const STARTUP_FLAG = '--install-startup';
const REMOVE_FLAG = '--remove-startup';

function installStartup() {
  if (!IS_WIN) {
    log('开机启动暂仅支持 Windows。');
    return;
  }
  const startupDir = path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
  const shortcutPath = path.join(startupDir, 'app-bridge.lnk');
  const cmdPath = path.join(ROOT, 'start.cmd');

  if (fs.existsSync(shortcutPath)) {
    log(`· 开机启动已存在：${shortcutPath}`);
    return;
  }
  if (!fs.existsSync(cmdPath)) {
    log('⚠ 找不到 start.cmd，无法安装开机启动');
    return;
  }

  // 用 PowerShell 创建快捷方式（比 VBS 更干净）
  const psScript = `
$ws = New-Object -ComObject WScript.Shell;
$s = $ws.CreateShortcut('${shortcutPath.replace(/'/g, "''")}');
$s.TargetPath = '${cmdPath.replace(/'/g, "''")}';
$s.WorkingDirectory = '${ROOT.replace(/'/g, "''")}';
$s.Description = 'app-bridge';
$s.Save();
`;
  const r = spawnSync('powershell', ['-NoProfile', '-Command', psScript], { windowsHide: true, timeout: 10_000 });
  if (r.status === 0) {
    log(`· 已安装开机启动（${shortcutPath}）`);
    log('  重启电脑后会自己跑起来，或者现在去启动文件夹确认。');
  } else {
    log('⚠ 安装开机启动失败，可手动把 start.cmd 的快捷方式放进 shell:startup');
  }
}

function removeStartup() {
  if (!IS_WIN) return;
  const startupDir = path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
  const shortcutPath = path.join(startupDir, 'app-bridge.lnk');
  try {
    fs.unlinkSync(shortcutPath);
    log('· 已移除开机启动。');
  } catch {
    log('· 没有找到开机启动项。');
  }
}

if (argv.has(REMOVE_FLAG)) { removeStartup(); process.exit(0); }
if (argv.has(STARTUP_FLAG)) { installStartup(); process.exit(0); }

// ───────────────────────── 配置 ─────────────────────────
function randomToken() {
  return crypto.randomBytes(18).toString('base64url');
}

const sha256hex = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

// 管理令牌的明文只留在这一个文件里（项目目录之外），config.json 里只放它的 sha256。
// 好处：config.json 可以放心截图/备份/发给别人，也不会在浏览器历史里留下 ?token=xxx。
const ADMIN_TOKEN_FILE = path.join(
  process.env.APPDATA || path.join(os.homedir(), '.config'),
  'app-bridge',
  'admin-token.txt',
);

function saveAdminPlain(token) {
  fs.mkdirSync(path.dirname(ADMIN_TOKEN_FILE), { recursive: true });
  fs.writeFileSync(ADMIN_TOKEN_FILE, `${token}\n`, { encoding: 'utf8', mode: 0o600 });
  return ADMIN_TOKEN_FILE;
}

/**
 * 管理令牌迁移：
 *   - 已有 adminTokenHash → 什么都不动；
 *   - 只有明文 adminToken（老版本）→ 算出 hash 存回去，明文搬到外部文件，再从 config 删掉；
 *   - 啥都没有 → 生成一把新的。
 * @returns {{ rotated: boolean, plain?: string, file?: string }}
 */
function ensureAdminSecret(cfg) {
  const hash = String(cfg.app.adminTokenHash || '').trim();
  if (/^[0-9a-f]{64}$/.test(hash) && cfg.app.adminToken === undefined) {
    return { rotated: false, changed: false };
  }

  const legacy = String(cfg.app.adminToken || '');
  const usable = legacy && !legacy.startsWith('change-me');
  const plain = usable ? legacy : randomToken();
  cfg.app.adminTokenHash = sha256hex(plain);
  delete cfg.app.adminToken;
  const file = saveAdminPlain(plain);
  return { rotated: !usable, changed: true, plain, file };
}

function ensureConfig() {
  if (!fs.existsSync(CONFIG)) {
    if (!fs.existsSync(EXAMPLE)) die('缺少 config.example.json，项目不完整');
    fs.copyFileSync(EXAMPLE, CONFIG);
    log('· 首次运行：已从 config.example.json 生成 config.json');
  }
  const cfg = JSON.parse(fs.readFileSync(CONFIG, 'utf8'));
  cfg.app ||= {};
  cfg.dsh ||= {};

  // 共享令牌（旧版兼容用）仍然明文放着，它只对 App 有意义
  let rotated = false;
  const value = String(cfg.app.token ?? '');
  if (!value || value.startsWith('change-me')) {
    cfg.app.token = randomToken();
    rotated = true;
  }

  const admin = ensureAdminSecret(cfg);
  if (admin.changed || rotated) {
    fs.writeFileSync(CONFIG, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
  }
  if (admin.rotated) log('· 已生成随机管理令牌');
  if (admin.plain) log(`· 管理令牌已存到：${admin.file}`);

  cfg.app.port = Number(cfg.app.port || 8790);
  return cfg;
}

// ───────────────────────── 依赖 ─────────────────────────
function ensureDeps() {
  const probe = path.join(ROOT, 'node_modules', '@deepseek-ai', 'dsh-host-apiproxy', 'package.json');
  if (fs.existsSync(probe)) return;
  log('· 第一次启动，正在安装依赖（约 20 秒）…');
  const npm = IS_WIN ? 'npm.cmd' : 'npm';
  const r = spawnSync(npm, ['install', '--no-audit', '--no-fund'], { cwd: ROOT, stdio: 'inherit', shell: IS_WIN });
  if (r.status !== 0) die('依赖安装失败。请确认 Node.js ≥ 22 已安装，并在本目录手动运行 npm install');
}

// ───────────────────────── 小工具 ─────────────────────────
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function probeDsh(baseUrl) {
  if (!baseUrl) return false;
  try {
    const r = await fetch(`${baseUrl}/api/settings/describe`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ type: 'client-request', rpcId: `boot-${Date.now()}`, method: 'settings/describe', payload: { args: {} } }),
      signal: AbortSignal.timeout(1500),
    });
    return r.status === 200 || r.status === 401;
  } catch {
    return false;
  }
}

function dshExeCandidates() {
  const list = [];
  if (process.env.LOCALAPPDATA) list.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'DeepSeek Harness', 'DeepSeek Harness.exe'));
  if (process.env.PROGRAMFILES) list.push(path.join(process.env.PROGRAMFILES, 'DeepSeek Harness', 'DeepSeek Harness.exe'));
  if (process.env['PROGRAMFILES(X86)']) list.push(path.join(process.env['PROGRAMFILES(X86)'], 'DeepSeek Harness', 'DeepSeek Harness.exe'));
  return list.filter((p) => fs.existsSync(p));
}

function lanUrls(port) {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const ni of list || []) {
      if (ni.family === 'IPv4' && !ni.internal && !ni.address.startsWith('169.254.')) {
        out.push(`http://${ni.address}:${port}`);
      }
    }
  }
  return out.sort((a, b) => (a.includes('192.168.') ? -1 : 1) - (b.includes('192.168.') ? -1 : 1));
}

async function waitHttp(url, timeoutMs = 20_000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    try { const r = await fetch(url, { signal: AbortSignal.timeout(1200) }); if (r.ok) return true; } catch { /* 继续等 */ }
    await sleep(300);
  }
  return false;
}

/**
 * 把控制台地址交给系统浏览器。
 *
 * 老写法只有一条路：`cmd /c start "" <url>`。它在不少 Windows 上是「静默失败」的 ——
 * cmd 起来了、start 也没报错，但浏览器就是不弹（默认浏览器关联被改坏、被安全软件拦、
 * 或者 http 协议指向了某个已经卸载的程序）。
 * 现在三条路依次试，前两条走 ShellExecute，不经过 cmd 的参数解析：
 *   rundll32 url.dll,FileProtocolHandler  —— 等价于双击一个 .url 文件，最稳
 *   explorer.exe <url>                    —— 交给外壳处理
 *   cmd /c start "" <url>                 —— 兜底
 * 三条都不行才打印手动地址，不再假装成功。
 */
function openBrowser(url) {
  if (argv.has('--no-open') || argv.has('--quiet')) return;

  if (!IS_WIN) {
    try {
      if (process.platform === 'darwin') spawn('open', [url], { detached: true, stdio: 'ignore' }).unref();
      else spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
    } catch { /* 打不开就算了 */ }
    return;
  }

  // rundll32 正常时退出码是 0；非 0 说明这条路没成，继续下一条
  const rundll = spawnSync('rundll32', ['url.dll,FileProtocolHandler', url], {
    windowsHide: true, timeout: 8000,
  });
  if (!rundll.error && rundll.status === 0) return;

  try {
    // explorer 无论如何都返回 1，所以只认「有没有启动失败」，不看退出码
    const ex = spawnSync('explorer.exe', [url], { windowsHide: true, timeout: 8000 });
    if (!ex.error) return;
  } catch { /* 换下一条 */ }

  try {
    spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    return;
  } catch { /* 三条都没成 */ }

  log(`· 浏览器没能自动打开，请手动访问：${url}`);
}

function readPid() {
  try { return JSON.parse(fs.readFileSync(PID_FILE, 'utf8')); } catch { return null; }
}

function alive(pid) {
  if (!pid) return false;
  try { process.kill(pid, 0); return true; } catch { return false; }
}

// 在现有状态里找一个初始用户的可用 userId
function pickFirstUserId(existing) {
  const set = new Set(existing.map((u) => u.userId));
  for (const n of ['app', 'user', 'u1', 'me']) { if (!set.has(n)) return n; }
  let i = 2;
  while (set.has(`u${i}`)) i++;
  return `u${i}`;
}

// ───────────────────────── 主流程 ─────────────────────────
const cfg = ensureConfig();
ensureDeps();
fs.mkdirSync(STATE_DIR, { recursive: true });
fs.mkdirSync(LOG_DIR, { recursive: true });
try { fs.unlinkSync(path.join(STATE_DIR, 'stopped.flag')); } catch { /* 上次是正常停止 */ }

const port = cfg.app.port;
const selfUrl = `http://127.0.0.1:${port}/`;

// 已经在跑？只打开状态页
if (!argv.has('--force')) {
  const pid = readPid();
  if (pid?.bridge && alive(pid.bridge) && (await waitHttp(`${selfUrl}v1/health`, 1500))) {
    log('\n已经有一个实例在跑了，直接打开控制台。');
    log(`  控制台：${selfUrl}`);
    const cached = readTunnelUrl();
    if (cached) log(`  手机填这个：${cached}`);
    log('  要强行重启：start.cmd --force\n');
    openBrowser(selfUrl);
    process.exit(0);
  }
}

log('\n──────── app-bridge 启动 ────────');

// DSH：探活 → 自动发现 → 试着拉起
let dshBase = String(cfg.dsh.baseUrl || '');
let dshOnline = await probeDsh(dshBase);

if (!dshOnline) {
  log('· DSH 没在配置的地址上，正在自动查找…');
  try {
    const { discoverDshBaseUrl } = await import('../lib/dsh-endpoint.js');
    const found = await discoverDshBaseUrl({ current: dshBase, log: () => {} });
    if (found) { dshBase = found; dshOnline = true; log(`· 找到 DSH：${found}`); }
  } catch { /* 发现失败不致命 */ }
}

if (!dshOnline && !argv.has('--no-dsh')) {
  const exes = dshExeCandidates();
  if (exes.length) {
    log('· DSH 没开，正在帮你启动它（首次可能要几十秒）…');
    spawn(exes[0], [], { detached: true, stdio: 'ignore' }).unref();
    for (let i = 0; i < 60 && !dshOnline; i++) {
      await sleep(1500);
      const { discoverDshBaseUrl } = await import('../lib/dsh-endpoint.js');
      const found = await discoverDshBaseUrl({ current: dshBase, log: () => {} }).catch(() => null);
      if (found) { dshBase = found; dshOnline = true; log(`· DSH 已就绪：${found}`); }
    }
  } else {
    log('· 没找到 DSH 的可执行文件，请手动打开 DeepSeek Harness。');
  }
}

if (!dshOnline) log('⚠ DSH 还没起来，桥接会先启动并自动重连（它会自己找回端口）。');

// ── 创建第一个用户令牌（如果还没有用户） ──
let userToken = null;
let userDisplay = null;
let firstUserId = null;
const usersPath = path.join(STATE_DIR, 'users.json');
let existingUsers = [];
// users.json 现在是密文，必须解密才能判断「有没有用户」。
// 万一密钥丢了，这里绝不能当成空文件往下走 —— 那会凭空再建一个用户，
// 把原来那个人挡在门外。宁可报错停下。
try {
  initVault({ probeFiles: [usersPath] });
  existingUsers = await readJson(usersPath, []);
  if (!Array.isArray(existingUsers)) existingUsers = [];
} catch (e) {
  die(`读不了 state/users.json：${e.message}`);
}

if (existingUsers.length === 0) {
  firstUserId = pickFirstUserId(existingUsers);
  userToken = randomToken();
  userDisplay = '用户';
  log(`· 创建第一个用户令牌（可由此人在手机 App 上使用）：`);
  log(`  userId: ${firstUserId}`);
  log(`  token:  ${userToken}`);
}

// 桥接子进程 + 守护
let child = null;
let stopping = false;
let restarts = 0;
const logFile = path.join(LOG_DIR, `bridge-${new Date().toISOString().slice(0, 10)}.log`);
const logStream = fs.createWriteStream(logFile, { flags: 'a' });

function writeLog(line) {
  process.stdout.write(line);
  logStream.write(line);
}

function startBridge() {
  const env = {
    ...process.env,
    APP_BRIDGE_LAUNCHED: '1',
  };
  // 注入初始用户到桥接进程，让它直接写进 state/users.json
  if (firstUserId && userToken) {
    env.APP_BRIDGE_INIT_USER_ID = firstUserId;
    env.APP_BRIDGE_INIT_TOKEN = userToken;
    env.APP_BRIDGE_INIT_DISPLAY = userDisplay || firstUserId;
  }

  child = spawn(process.execPath, [path.join(ROOT, 'src', 'bridge.mjs')], {
    cwd: ROOT,
    env,
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stdout.on('data', (d) => writeLog(d));
  child.stderr.on('data', (d) => writeLog(d));

  // 守护重启后同步 bridge PID，避免单实例检查拿着已退出的旧 PID
  try {
    const pidData = JSON.parse(fs.readFileSync(PID_FILE, 'utf8'));
    pidData.bridge = child.pid;
    fs.writeFileSync(PID_FILE, JSON.stringify(pidData, null, 2));
  } catch { /* 首次启动时 pid.json 还没生成 */ }

  child.on('exit', (code) => {
    if (stopping) return;
    restarts++;
    if (restarts > 20) {
      log('\n✗ 桥接反复退出，已停止自动重启。日志：' + logFile);
      logStream.end();
      process.exit(1);
    }
    writeLog(`\n[launcher] 桥接退出（code=${code}），3 秒后重启（第 ${restarts} 次）\n`);
    setTimeout(() => { if (!stopping) startBridge(); }, 3000);
  });
}

startBridge();

// 等桥接起来，然后打印面板
const ready = await waitHttp(`${selfUrl}v1/health`, 30_000);
const lan = lanUrls(port);

// ── HTTPS 隧道 ──
// Android release 包禁止明文 HTTP（network_security_config 只放行 jsnu.edu.cn），
// 所以手机不能填 http://10.x.x.x:8790。给 8790 套一层 quick tunnel，
// 手机填 https://*.trycloudflare.com 即可，还不用和电脑在同一 WiFi。
let tunnel = null;
let tunnelUrl = null;
if (!argv.has('--no-tunnel') && ready) {
  const tunnelMode = String(cfg?.tunnel?.mode || 'quick').toLowerCase();
  log('· 正在建立 HTTPS 隧道（手机要用这个地址）…');
  tunnel = startTunnel({ port, cfg });
  if (!tunnel) {
    if (tunnelMode === 'named') {
      log('  ⚠ 命名隧道起不来：config.json 的 tunnel.token 是空的，或者找不到 cloudflared.exe');
    } else {
      log('  ⚠ 找不到 cloudflared.exe，跳过隧道（把它放进 bin/ 即可）');
    }
  } else {
    // named 模式地址是固定的，health 不通也可能只是本机 DNS 还没刷新 NS，
    // 不用像 quick 模式那样死等 40 秒；进程活着就认为隧道已建立。
    tunnelUrl = await tunnel.waitForUrl(tunnel.named ? 8_000 : 40_000);
    if (tunnelUrl) {
      log(`  ✓ 隧道已就绪：${tunnelUrl}${tunnel.named ? '（固定地址，重启也不变）' : ''}`);

      // quick 模式地址每次都变，如果配了 Worker 中转就顺手把新地址报上去，
      // 手机侧只认中转地址，永远不用改。named 模式地址本来就是固定的，不用报。
      const relayUrl = String(cfg?.relay?.url || '').replace(/\/+$/, '');
      if (!tunnel.named && relayUrl && cfg?.relay?.secret) {
        try {
          const r = await fetch(`${relayUrl}/__register`, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ secret: cfg.relay.secret, url: tunnelUrl }),
            signal: AbortSignal.timeout(10_000),
          });
          log(r.ok
            ? `  ✓ 已同步到中转：${relayUrl}（手机填这个就行）`
            : `  ⚠ 中转上报被拒：HTTP ${r.status}，检查 relay.secret`);
        } catch (e) {
          log(`  ⚠ 中转上报失败：${e.message}（手机侧暂时连不上固定地址）`);
        }
      }

      tunnel.child.on('exit', () => {
        clearTunnelUrl();
        if (!stopping) {
          log(tunnel.named
            ? '\n⚠ 隧道断了，重启 start.cmd 重连即可，地址不变\n'
            : '\n⚠ 隧道断了，重启 start.cmd 可以重新拿一个地址\n');
        }
      });
    } else {
      log('  ⚠ 隧道 40 秒没起来，看 logs/tunnel.log');
    }
  }
}

log('');
if (ready) {
  log('✓ 已经跑起来了');
} else {
  log('⚠ 桥接还没响应，检查上面的日志');
}
log('');

// ── 打印令牌信息 ──
if (userToken) {
  log(`  ┌──────────────────────────────────────────────┐`);
  log(`  │ ● 下面这个 token 填进你的手机 App          │`);
  log(`  │   userId: ${(firstUserId + '               ').slice(0, 30)}`);
  log(`  │   token:  ${(userToken + '               ').slice(0, 30)}`);
  log(`  └──────────────────────────────────────────────┘`);
} else {
  log(`  userId: 已经存在，在控制台里查看/创建新用户。`);
}
log('');
log(`  管理令牌（点登录框要的就是它）`);
log(`    文件  ${ADMIN_TOKEN_FILE}`);
log(`    丢了  双击 reset-admin.cmd 重新生成一把`);

if (tunnelUrl) {
  log(`  手机填这个  ${tunnelUrl}`);
  log(`              ↑ HTTPS，不用和电脑同一 WiFi，release 包也能连`);
  if (lan[0]) log(`  同一 WiFi 备用  ${lan[0]}  （HTTP，仅 debug 包可用）`);
} else {
  log(`  手机填这个  ${lan[0] || `http://<这台电脑的局域网IP>:${port}`}`);
  if (lan.length > 1) log(`              ${lan.slice(1).join('   ')}`);
}
log('');
log(`  DSH         ${dshOnline ? dshBase : '未连接（会自动重连）'}`);
log(`  控制台      ${selfUrl}  （管理令牌登录）`);
log(`  日志        ${logFile}`);
log('');
log(`  关闭这个窗口 = 停止服务。最小化别关。`);
log(`  开机自启：  start.cmd --install-startup`);
log('────────────────────────────────\n');

// 不写令牌：pid.json 只是运行信息，没必要把钥匙抄一份在磁盘上
fs.writeFileSync(PID_FILE, JSON.stringify({
  launcher: process.pid, bridge: child?.pid,
  dshUrl: dshBase, port, startedAt: Date.now(),
  firstUserId,
  tunnelPid: tunnel?.child?.pid ?? null, phoneUrl: tunnelUrl,
}, null, 2));

if (ready) openBrowser(selfUrl);

const shutdown = () => {
  if (stopping) return;
  stopping = true;
  try { child?.kill(); } catch { /* ignore */ }
  try { tunnel?.stop(); } catch { /* ignore */ }
  try { fs.unlinkSync(PID_FILE); } catch { /* ignore */ }
  logStream.end();
  log('\n已停止。');
  process.exit(0);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('SIGHUP', shutdown);
if (IS_WIN) process.on('SIGBREAK', shutdown);
