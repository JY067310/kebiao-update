// app-bridge / scripts/test-memory.mjs
//
// 长期记忆的自测：不连 DSH、不碰真实 state/memory，全部跑在临时目录里。
//   node scripts/test-memory.mjs
//
// 重点验证用户最在意的三件事：
//   1. 重要的事不会被压缩掉（模型手滑丢了也有兜底）
//   2. 被压缩的琐事仍留有「淡印象」，聊到相关话题能浮上来
//   3. 会话重置 / 桥接重启后，记忆仍然在

import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {
  MemoryStore, parseCompression, similarity, buildCompressPrompt,
} from '../src/memory.mjs';

const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'wbmem-'));
const convId = 'app:dev_test-小娅';
let passed = 0;
const check = (name, fn) => {
  fn();
  passed += 1;
  console.log(`  ✓ ${name}`);
};

const makeStore = (ask, config = {}) => new MemoryStore({
  root: tmp,
  config: {
    dir: 'memory',
    compressAfterUserTurns: 2,
    compressIdleMs: 0,
    compressMaxAgeMs: 999_999_999,
    ...config,
  },
  log: () => {},
  ask,
});

// ── 纯函数 ──
console.log('纯函数');
check('parseCompression 容忍 markdown 代码块和前后废话', () => {
  const r = parseCompression('好的，这是结果：\n```json\n{"portrait":"对方是阿夜","keep":[{"text":"他在师大读书","importance":5}],"faint":[{"hint":"印象里提过橘猫"}],"drop":[{"text":"旧的错误条目","why":"记错了"}],"note":"保留身份"}\n```\n以上。');
  assert.equal(r.portrait, '对方是阿夜');
  assert.equal(r.keep.length, 1);
  assert.equal(r.keep[0].importance, 5);
  assert.equal(r.faint[0].hint, '印象里提过橘猫');
  assert.equal(r.drop[0].why, '记错了');
});
check('压缩提示词明确区分「对方说的」和「自己猜的」', () => {
  const p = buildCompressPrompt({ portrait: '', core: [], faint: [], buffer: [{ role: 'user', text: '你好' }] }, 7000);
  assert.match(p, /只有 \[对方\] 说的话才是关于他的信息/);
  assert.match(p, /drop/);
});
check('parseCompression 拒绝非 JSON 回复', () => {
  assert.throws(() => parseCompression('我不知道该怎么整理'), /没有 JSON 对象/);
});
check('相似度：中文改写算相似，无关内容不相似', () => {
  assert.ok(similarity('他在准备期末考试', '他期末考试考完了') > 0.2);
  assert.equal(similarity('他在准备期末考试', '今天天气不错适合散步'), 0);
});
check('压缩提示词把判断权交给模型、并要求保留淡印象', () => {
  const p = buildCompressPrompt({
    portrait: '对方是阿夜', core: [{ id: 1, text: '他在师大读书' }],
    faint: [{ hint: '印象里提过橘猫' }],
    buffer: [{ role: 'user', text: '我叫阿夜' }, { role: 'assistant', text: '记住啦' }],
  }, 7000);
  assert.match(p, /请你自己判断轻重/);
  assert.match(p, /不要直接扔掉/);
  assert.match(p, /他在师大读书/);
  assert.match(p, /我叫阿夜/);
});

// ── 全流程 ──
console.log('全流程');
let modelReply = '';
let askCalls = 0;
const ask = async () => {
  askCalls += 1;
  return { ok: true, text: modelReply };
};
const store = makeStore(ask);
await store.init();

await store.pin(convId, '对方叫阿夜，在江苏师范大学读书');
await store.pin(convId, '他最在意的是别被忘记');

store.recordUser(convId, '今天在图书馆待了一下午，累死了');
store.recordAssistant(convId, '这么拼啊，眼睛要不要歇会儿');
store.recordUser(convId, '楼下有只橘猫，老蹭我');
store.recordAssistant(convId, '橘猫诶，改天带我看看');
store.recordUser(convId, '对了，我下周要考古代文学');
await store.save(convId);

assert.equal(store.needsCompress(convId), true, '聊够轮数应触发压缩');
passed += 1;
console.log('  ✓ 聊够轮数自动触发压缩');

// 模型「忘了」两条重要事实里的一条，只给了一条改写版 + 新的淡印象
modelReply = JSON.stringify({
  portrait: '对方是阿夜，在江苏师范大学读书，最近在准备古代文学考试。',
  keep: [{ text: '对方叫阿夜，在江苏师范大学读书', importance: 5 }],
  faint: [
    { hint: '印象里他在图书馆泡过一整个下午，挺累的' },
    { hint: '好像提过楼下有只爱蹭人的橘猫' },
    { hint: '下周有个古代文学的考试' },
  ],
  note: '身份和关系留清楚，琐事压成印象',
});
const ok = await store.compress(convId, { force: true });
assert.equal(ok, true, '压缩应成功');
let d = store.describe(convId);
assert.equal(d.stats.compressCount, 1);
assert.equal(d.bufferCount, 0, '压缩后 buffer 应清空');
passed += 1;
console.log('  ✓ 压缩成功、buffer 清空');

check('重要事实被模型丢掉时自动兜底找回', () => {
  assert.ok(d.core.some((f) => f.text.includes('别被忘记')), '被丢掉的 core 应补回');
  assert.ok(d.core.some((f) => f.text.includes('江苏师范大学')), '保留的 core 还在');
});

check('琐碎内容压成「淡印象」而不是消失', () => {
  assert.equal(d.faintCount, 3);
  assert.ok(d.faintSample.some((h) => h.includes('橘猫')));
  assert.ok(d.faintSample.some((h) => h.includes('图书馆')));
});

const block = store.promptBlock(convId, '今天又见到那只橘猫了');
check('注入分层：重要事实 + 淡印象都在', () => {
  assert.match(block, /【你一直记得的事】/);
  assert.match(block, /【印象里还有这些】/);
  assert.match(block, /江苏师范大学/);
});
check('聊到相关话题时，橘猫的淡印象会被唤起', () => {
  assert.match(block, /橘猫/);
});

// 改写更新不应被当成「误删」而重复补回
console.log('安全网边界');
const store2 = makeStore(ask, { dir: 'memory2' });
await store2.init();
await store2.pin(convId, '他在准备期末考试');
store2.recordUser(convId, '考完啦');
modelReply = JSON.stringify({
  portrait: '对方刚考完试。',
  keep: [{ text: '他期末考试考完了', importance: 5 }],
  faint: [],
  note: '状态更新',
});
await store2.compress(convId, { force: true });
const d2 = store2.describe(convId);
check('重要事实被「改写更新」时不重复补回旧版本', () => {
  assert.equal(d2.core.length, 1, `期望 1 条，实际 ${d2.core.length}`);
  assert.match(d2.core[0].text, /考完了/);
});

// 她发现自己记错了，明确要求删掉
const store6 = makeStore(ask, { dir: 'memory6' });
await store6.init();
await store6.pin(convId, '对方吃饭不规律，总拖到两三点才吃');
store6.recordUser(convId, '我没说过这个啦');
modelReply = JSON.stringify({
  portrait: '对方是阿夜。',
  keep: [{ text: '对方叫阿夜', importance: 5 }],
  faint: [],
  drop: [{ text: '对方吃饭不规律，总拖到两三点才吃', why: '那是我自己猜的，对方没确认' }],
  note: '删掉误记',
});
await store6.compress(convId, { force: true });
check('她主动纠正记错的事时不再被安全网补回', () => {
  const d6 = store6.describe(convId);
  assert.ok(!d6.core.some((f) => f.text.includes('两三点')), '误记应被删掉');
  assert.ok(d6.core.some((f) => f.text.includes('阿夜')));
});

// 失败不清 buffer
const store3 = makeStore(async () => ({ ok: false, error: '模拟 DSH 掉线' }), { dir: 'memory3' });
await store3.init();
store3.recordUser(convId, '这句话不能丢');
await store3.save(convId);
const ok3 = await store3.compress(convId, { force: true });
check('压缩失败时 buffer 保留、下次能重试', () => {
  assert.equal(ok3, false);
  assert.equal(store3.describe(convId).bufferCount, 1);
  assert.match(store3.describe(convId).stats.lastError, /DSH 掉线/);
});

// 模拟桥接重启：新实例从磁盘读回
const store4 = makeStore(ask, { dir: 'memory' });
await store4.init();
const d4 = store4.describe(convId);
check('重启后记忆仍在（与 DSH sessionId 无关）', () => {
  assert.ok(d4, '应能读到记忆');
  assert.ok(d4.core.some((f) => f.text.includes('江苏师范大学')));
  assert.equal(d4.faintCount, 3);
  assert.equal(d4.stats.compressCount, 1);
});

// 清空
await store4.clear(convId);
const store5 = makeStore(ask, { dir: 'memory' });
await store5.init();
check('清空后不再残留隐私记忆', () => {
  assert.equal(store5.describe(convId), null);
});

// ── 信息隔离 ──
console.log('信息隔离');
const store8 = makeStore(ask, { dir: 'memory8' });
await store8.init();
store8.recordUser(convId, '我是 A，这句话只该属于 A', 'userA');
await store8.save(convId);
check('归属 userId 写进记忆文件本身', () => {
  assert.equal(store8.get(convId, 'userA').userId, 'userA');
});
check('别的用户读不到、也注入不了这份记忆', () => {
  assert.equal(store8.get(convId, 'userB'), null);
  assert.equal(store8.promptBlock(convId, '随便问一句', 'userB'), '');
  store8.recordUser(convId, '我是 B，想混进来', 'userB');
  assert.equal(store8.get(convId, 'userA').buffer.length, 1, 'B 的话不能写进 A 的 buffer');
});
const store9 = makeStore(ask, { dir: 'memory8' });
await store9.init();
check('重启后归属仍在，别人照样读不到', () => {
  assert.equal(store9.get(convId, 'userB'), null);
  assert.equal(store9.get(convId, 'userA').userId, 'userA');
});
const removedCount = await store9.clearByUser('userA');
check('撤销用户时连记忆（含孤儿文件）一起清掉', () => {
  assert.equal(removedCount, 1);
  assert.equal(store9.describe(convId), null);
});

// 清空竞态：压缩要跑一会儿，期间被清空，结果不能写回来
const slowAsk = async () => {
  await new Promise((r) => setTimeout(r, 60));
  return { ok: true, text: modelReply };
};
const store10 = makeStore(slowAsk, { dir: 'memory10' });
await store10.init();
store10.recordUser(convId, '这句话清空后不能复活', 'userA');
modelReply = JSON.stringify({
  portrait: '不该被写回来',
  keep: [{ text: '不该被写回来', importance: 5 }],
  faint: [], drop: [], note: '',
});
const running = store10.compress(convId, { force: true });
await store10.clear(convId);
const survived = await running;
check('压缩期间被清空，结果不会把记忆写回来', () => {
  assert.equal(survived, false);
  assert.equal(store10.describe(convId), null);
});

// 老版本残留文件：没有归属标记，绝不能被「谁先访问谁认领」
const store11 = makeStore(ask, { dir: 'memory11' });
await store11.init();
await store11.pin(convId, '一份没有归属的旧记忆');
await store11.save(convId);
const store12 = makeStore(ask, { dir: 'memory11' });
await store12.init({});
check('无归属的残留记忆谁都认领不了', () => {
  assert.equal(store12.get(convId, 'anyone'), null);
  assert.equal(store12.promptBlock(convId, '你好', 'anyone'), '');
  assert.equal(store12.describe(convId).core.length, 1, '管理员仍看得见、能清理');
});
const store13 = makeStore(ask, { dir: 'memory11' });
await store13.init({ [convId]: 'userA' });
check('能对上现有会话的旧文件，启动时自动补写归属', () => {
  assert.equal(store13.get(convId, 'userA').userId, 'userA');
  assert.equal(store13.get(convId, 'userB'), null);
});

await fs.rm(tmp, { recursive: true, force: true });
console.log(`\n全部通过：${passed} 项`);
