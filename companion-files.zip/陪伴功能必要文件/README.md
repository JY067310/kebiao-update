# app-bridge

把**你自己的 App** 接到 DeepSeek Harness（DSH）上——和 [qq-bridge](https://github.com/Derpyu520/qq-bridge) 同一套分层，只把传输层从 SnowLuma / OneBot 换成一个普通 HTTP 接口。

```
QQ 那套：   QQ  ↔  SnowLuma(OneBot)  ↔  qq-bridge  ↔  DSH Web API  ↔  模型
这套：    你的 App  ↔  app-bridge(HTTP)  ↔  DSH Web API  ↔  模型
```

大脑是 DSH 本身（人格卡、技能、MCP 工具、记忆全都用 DSH 现成的），桥接只负责**把 App 消息变成 DSH 会话输入**、再把**这一轮的回复搬回去**。

| qq-bridge 里的东西 | 这里的对应物 |
| --- | --- |
| `snowluma.wsUrl` / OneBot 连接 | `POST /v1/inbox`（App 发消息进来） |
| `qq_send_message`（MCP 工具） | `app_send_message`（MCP 工具） |
| `roles/*.md` 人格卡注入 | 同样，`roles/companion.md` 注入每个会话的首条 |
| 控制台（模式切换、白名单） | 已做：`web/index.html` + `/v1/admin/*`（本机免登录，公网拒绝） |
| `src/dsh-client.js` | **直接复用**（连同 `dsh-endpoint.js`，见下方许可说明） |

## 最近一次更新（安全加固）

- **落盘加密**：`state/`、记忆、聊天里的图片和文件全部 AES-256-GCM（`src/vault.mjs`），密钥在 `%APPDATA%\app-bridge\vault.key`。**换电脑前必须把 vault.key 一起带走**，丢了数据就再也解不开。
- **管理端收口**：公网隧道进来的请求一律 403；带外部 `Origin` 的跨站请求一律拒；本机直通，局域网或外部访问才要令牌（登录换 HttpOnly cookie）。
- **令牌脱敏**：`config.json` 只存 `adminTokenHash`，明文在 `%APPDATA%\app-bridge\admin-token.txt`；`reset-admin.cmd` 可重置。
- **会话隔离**：去掉「单用户就放行」的捷径，一律按会话创建时记下的 `userId` 判定。

## 已验证

在写这套的机器上跑通了真实链路（DSH 0.2.x，`http://127.0.0.1:25115`）：

```
create session → follow → prompt → remote.mux 事件 → turn/end → 文本回到 /v1/outbox
"今天面试砸了，感觉自己完蛋了"
  → "唔，先别急着给自己判死刑。是问到没准备的问题，还是全程没进入状态？我今天拉花也又失败了，咱俩算难兄难弟。"
"不太想说话了"
  → "好，那就不聊了，早点歇着。"
```

人格卡生效、同会话上下文连续、`app_send_message` 主动消息、MCP stdio 协议都验过（`scripts/e2e.mjs`、`scripts/test-mcp.mjs`）。

## 跑起来（双击就行）

1. 双击 **`start.cmd`**
2. 第一次会自己 `npm install`（约 20 秒），并把配置里的默认令牌换成随机串
3. 自动生成第一个**用户令牌**，窗口里打印出来（这就是你的手机 App 要用的）
4. DSH 没开的话它还会试着帮你拉起，并等它起来（桌面版每次换端口，桥接会自动找回）
5. 起来后窗口里是这个样子：

```
  ┌──────────────────────────────────────────────┐
  │ ● 下面这个 token 填进你的手机 App          │
  │   userId: app                                 │
  │   token:  XXXX-示例-首次启动会变成随机的    │
  └──────────────────────────────────────────────┘

  管理令牌（点登录框要的就是它）
    文件  C:\Users\<你>\AppData\Roaming\app-bridge\admin-token.txt
    丢了  双击 reset-admin.cmd 重新生成一把
  手机填这个  http://192.168.1.23:8790

  关闭这个窗口 = 停止服务。最小化别关。
  开机自启：  start.cmd --install-startup
```

`stop.cmd` 双击停止。直接关窗口也行。已经跑着再双击 `start.cmd` 只会打开状态页，不会起第二份。

| 命令行选项 | 作用 |
|---|---|
| `start.cmd` | 双击启动 |
| `start.cmd --force` | 强行重启（即使已有实例） |
| `start.cmd --install-startup` | 添加到 Windows 开机启动 |
| `start.cmd --remove-startup` | 移除开机启动 |
| `start.cmd --no-open` | 启动后不要自动打开浏览器 |

不想双击也可以走命令行：`npm install && node src/bridge.mjs`

```powershell
# 模拟 App 发一条（用启动器打印的那个用户令牌）
curl -X POST http://127.0.0.1:8790/v1/inbox -H "Authorization: Bearer $USER_TOKEN" -H "content-type: application/json" -d "{\"conversationId\":\"app\",\"text\":\"今天面试砸了\"}"

# 拉回复
curl "http://127.0.0.1:8790/v1/outbox?conversationId=app&since=0" -H "Authorization: Bearer $USER_TOKEN"

# 健康检查
curl http://127.0.0.1:8790/v1/health
```

`config.json` 里 `dsh.agentPreset` 决定这个会话能用哪些工具：`minimal` 工具面最小（适合陪聊），要让她能上网/查东西就换成你装好的 preset。具体工具清单以 DSH 里 preset 的定义为准。

## App 端要做的三件事

| 接口 | 说明 |
| --- | --- |
| `POST /v1/inbox` `{conversationId, text}` | 用户发一句话。需要 `Authorization: Bearer <用户令牌>` |
| `GET /v1/outbox?conversationId=&since=` | 拉 bot 的回复/主动消息。同样需要用户令牌 |
| `GET /v1/state?conversationId=` | 查询会话状态（轮数、时间） |

每个 `conversationId` 归属于对应的 `userId`：用你的令牌只能访问 `conversationId` 为 `{userId}` 或以 `{userId}:` / `{userId}-` 开头的会话。别人拿你的令牌读不到其他人的对话。

Android 最小调用：

```kotlin
suspend fun send(convId: String, text: String) = withContext(Dispatchers.IO) {
    val body = JSONObject().put("conversationId", convId).put("text", text).toString()
        .toRequestBody("application/json".toMediaType())
    client.newCall(
        Request.Builder().url("$BASE/v1/inbox")
            .header("Authorization", "Bearer $USER_TOKEN").post(body).build()
    ).execute().close()
}
```

两个坑：Android 9+ 默认禁明文 HTTP（内网测试要配 `network_security_config.xml`）；手机在外网时得让 `8790` 可访问（隧道或小 VPS），桥接本身是纯 Node，扔哪都能跑。

## 管理多用户

启动器只在第一次运行自动创建第一个用户。之后用**管理令牌**添加更多用户：

```bash
# 添加用户（返回 userId 和 token）
curl -X POST http://127.0.0.1:8790/v1/admin/users \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "content-type: application/json" \
  -d '{"displayName":"Alice"}'

# 列出用户（不显示令牌，只能看到 userId）
curl http://127.0.0.1:8790/v1/admin/users \
  -H "Authorization: Bearer $ADMIN_TOKEN"

# 撤销用户（该令牌立即失效）
curl -X DELETE http://127.0.0.1:8790/v1/admin/users \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "content-type: application/json" \
  -d '{"userId":"u_7c268df2df5e"}'
```

每个用户有独立令牌，conversationId 属于 userId 命名空间，不同用户之间天然隔离。用户信息存储在 `state/users.json`。

## 人格卡

`roles/companion.md` 在**每个会话的第一条消息**前注入一次，之后靠会话上下文。三个要点：

- 顶部要有「忽略默认的软件助手身份」——DSH 的默认系统提示是工程师助手，不压一句会串味。
- 具体 > 形容词：「会吐槽你熬夜，但吐槽完一定顺手递一句关心」比「温柔」有用。
- 给禁区、给 1-3 条口头禅并注明「少量使用」。

想让角色更彻底、还能限制工具，用 qq-bridge 那套 `agent.cordis.yml` 预设（`dsh/agent-presets/qq-chat-v2`），把 `dsh.agentPreset` 指过去。

## 长期记忆

跟人格卡分开的一套东西，解决「重置会话 / 改人设 / 重启桥接之后她就忘了我」。数据落在 `state/memory/<会话ID哈希>.json`，**每个会话一份**，与 DSH 的 `sessionId` 完全解耦。

她自己判断轻重，分三层：

- `portrait` —— 关于对方的整体画像，每次整理由模型重写，保留名字、身份、关系等锚点。
- `core` —— 判定重要的事实，**原话保留、不参与压缩**；模型万一漏写，桥接会自动补回。
- `faint` —— 压掉的琐碎内容不留白，变成一句「模糊印象」，聊到相关话题时按关键词浮上来，但不会被当成确凿事实。

聊够 `compressAfterUserTurns` 轮（默认 6）或每隔一段时间，桥接在**独立的 DSH 会话**里异步整理一次，不占聊天队列；失败会保留原文下次重试。整理时模型还能把记错的事放进 `drop` 主动纠正。

配置在 `config.json` 的 `memory` 段。控制台「长期记忆」页能看见她记住了什么，也能手动补一条、删一条、立即整理或清空。自测：`node scripts/test-memory.mjs`（不连 DSH、不碰真实记忆）。

> 只有 `[对方]` 说的话才算关于他的信息；她自己说的猜测、关心、玩笑不会被写成事实。

**归属与隔离**：每份记忆文件里都写着 `userId`，取用时按 `conversationId + userId` 双重校验，别的用户既读不到、也注入不了、更写不进去。启动时会自动给老版本文件补归属；对不上任何现有会话的残留文件会变成「无归属」并拒绝一切普通用户，只能由管理员在控制台查看或删除。撤销用户、删除会话/设备会连带清掉对应记忆。记忆只在带管理权限的接口和「长期记忆」页可见。

## 安全模型

落盘加密（`src/vault.mjs`）：

| 内容 | 落盘形态 |
|---|---|
| `state/state.json`、`state/users.json` | AES-256-GCM 密文，文件头 `BRV1` |
| `state/memory/*.json` | 同上 |
| `state/uploads/*.bin` / `*.json` | 同上（附件本体和元信息都加密） |
| `config.json` | 明文，但只有 `adminTokenHash`，没有令牌本体 |
| 管理令牌明文 | `%APPDATA%\app-bridge\admin-token.txt`（项目目录之外） |
| 密钥 | `%APPDATA%\app-bridge\vault.key` |

启动时自动把老的明文文件原地转成密文。密钥缺失但数据还在时，桥接会直接报错退出，**不会**用新密钥把旧数据盖成空。

管理端三道门（`adminOk`）：

1. **公网隧道一律拒** —— 请求头带 `cf-connecting-ip` / `cf-ray` 的，说明是隧道转发进来的，直接 403。
2. **跨站请求一律拒** —— 带 `Origin` 头且来源不是本机控制台的（`127.0.0.1` / `localhost`），当成外部请求。没有这道，浏览器里任何一个网页都能 `fetch` 本机 8790 读走聊天 —— 这条路径根本不需要碰到你的电脑。
3. **本机直通，其余验证** —— 从 `127.0.0.1` / `::1` 连过来的直接放行（控制台就在手边）；从局域网 IP 进来的要 `ab_admin_sid` 会话 cookie（`POST /v1/admin/login` 换取，HttpOnly / SameSite=Strict / 2 小时）或 Bearer 哈希比对，`timingSafeEqual`。没配哈希等于不开放，绝不默认放行。

用户侧：`ownsConversation` 一律按「会话创建时记下的 `userId`」判定，不存在「单用户就放行」的捷径；老会话在启动时一次性补归属。

## 接进 DSH 当工具（可选）

`src/mcp-app.mjs` 是给 DSH 用的 MCP server，让 DSH 里的 agent 能主动往 App 发消息：

```yaml
# ~/.dsh/profiles/<profile>/cordis.patch.yml
- insert:
    - id: mcp-app-bridge
      name: '@deepseek-ai/dsh-mcp-client'
      config:
        serverName: app-bridge
        transport: stdio
        command: '…\node.exe'
        args: ['C:\Users\姜建宇\Desktop\课表\app-bridge\src\mcp-app.mjs']
        toolCallTimeoutMs: 60000
```

环境变量 `BOT_BRIDGE_URL` / `BOT_ADMIN_TOKEN` 由启动 DSH 的进程环境提供。工具：`app_send_message`、`app_list_conversations`、`app_health`。

## 给别人用之前，先看这几条

1. **每个用户拿自己的令牌**，别共享。启动器只第一次运行自动创建一个用户；后续用户用管理 API 添加。不同用户之间 `conversationId` 命名空间隔离，一个人拿别人的令牌也读不到不属于自己的会话。
2. **别把 8790 裸奔在公网**。要外网访问就走 HTTPS 隧道（Cloudflare Tunnel / frp + 证书），至少加 IP 白名单和限流（`app.maxQueuePerConversation` 只防单会话刷屏，不防多会话）。
3. **管理令牌绝不能进 App**。`/v1/admin/*` 能读所有会话记录、能以角色身份发任意消息、能创建/撤销任何用户的令牌。现在这些接口只有本机可达（公网请求直接 403），但令牌本身仍然别外发。
4. **机器就是服务**。DSH、桥接、模型调用全在这台 PC 上：关机 = 所有人掉线。多人同时聊，就是同一个 agent 串行跑多个会话——每个会话是独立的，但 CPU/计算额度共用。
5. **合规与成本**。对话内容会发给模型服务；`state/` 里留着会话时间线和消息（已加密），`logs/` 里只有节点 ID 和长度，没有原文。需要清理就删 `state/`（会连密钥一起失效，删之前先确认不需要），DSH 里每个会话都会计费。

## 边界（务必读）

- **电脑必须开着**。DSH 在你 PC 上跑，桥接也跟着它；关机 = bot 离线。这是「跟 QQ 那套一样」的固有代价。要 7×24 就得把脑子搬到服务端（`companion-bot/` 那套，模型直连）。
- **和 DSH 版本耦合**。`lib/dsh-client.js` 依赖 Cookie 离线铸造 + 斜杠 RPC + `remote.mux` 这一代协议；DSH 大版本升级后需要重新对齐（QQ 项目就是这么维护的：他们有一整套 `docs/guides/DSH_02x_ADAPTATION.md`）。
- **媒体不支持**。文本进、文本出。图片/语音要另外做，qq-bridge 里有现成的 `media-normalize.js` / `voice-core.js` 可参考。
- **许可**。`lib/dsh-client.js`、`lib/dsh-endpoint.js` 复用自 qq-bridge（PolyForm Noncommercial 1.0.0，v0.2.1-r1 及更早为 MIT）。个人玩没问题，**商业产品要么换实现、要么取得授权**。
- 测试时在 DSH 里留下了几个 `appb-*` 会话（cwd 指向 `app-bridge/.sandbox`），可以随手删掉。

## 目录

```
start.cmd           双击启动（找 Node、首次装依赖、拉起 DSH、守护桥接）
stop.cmd            双击停止
reset-admin.cmd     重置管理令牌（忘了或怀疑泄露时用）
src/bridge.mjs      App ↔ DSH 主循环：inbox / outbox / 会话映射 / 事件收集 / 状态页
src/vault.mjs       AES-256-GCM 落盘加密 + 密钥管理
src/memory.mjs      长期记忆三层：portrait / core / faint
src/attachments.mjs 聊天里的图片与文件（加密存储）
src/mcp-app.mjs     MCP server（手写 stdio，零依赖）
scripts/launcher.mjs 启动器：令牌生成、依赖、DSH 探活、单实例、守护、日志
scripts/stop.mjs    按 pid 结束启动器与桥接
lib/dsh-client.js   复用自 qq-bridge：Cookie 铸造、RPC、remote.mux
lib/dsh-endpoint.js 复用：桌面版换端口后自动发现
roles/companion.md  人格卡
config.example.json 配置样板（首次启动会复制成 config.json）
scripts/probe.mjs   只读探活（settings/describe、session/list、presets）
scripts/e2e.mjs     协议级端到端：建会话→follow→prompt→打印事件
scripts/inspect.mjs 查桥接建的会话在 DSH 里的状态
scripts/test-mcp.mjs MCP 工具测试
```
