# 固定地址中转（Cloudflare Worker）

## 这东西解决什么问题

`trycloudflare` 是临时隧道，**电脑每次重启，地址就变一次**，手机得跟着改。

这个 Worker 给你一个**永久不变的地址**（`https://xxx.workers.dev`，免费），
桥接启动时把新隧道地址报上去，手机永远只认那一个。地址变了，Worker 自己换过去。

```
手机 → https://你的.workers.dev（永久固定）
          ↓ Worker 查 KV 里记的当前隧道地址
       https://随机词.trycloudflare.com（每次重启都变）
          ↓
       你电脑的 8790
```

**完全免费**，不需要买域名、不需要信用卡。

---

## 部署（全程网页，约 10 分钟）

### 1. 注册 Cloudflare

<https://dash.cloudflare.com/sign-up>

邮箱 + 密码就行，不用绑卡。注册完可能要收一封验证邮件。

### 2. 建一个 KV（存当前地址用）

左侧菜单 **Storage & Databases → KV** → **Create a namespace**
- 名字随便写，比如 `app-bridge`
- 建完记下它，下一步要绑

### 3. 建 Worker

左侧 **Compute (Workers) → Workers & Pages** → **Create** → **Start with Hello World!**
- 名字填 `app-bridge`（或者你喜欢的）
- 创建后点 **Edit code**
- 把窗口里原来的代码**全删掉**，粘贴 `relay.js` 的内容
- 右上角 **Deploy**

### 4. 绑 KV

在你这个 Worker 的 **Settings → Bindings**（或 Variables）→ **Add** → **KV Namespace**
- **Variable name** 必须填 `BRIDGE_KV`（大小写要一模一样）
- **KV namespace** 选第 2 步建的那个
- 保存

### 5. 设一个暗号

同一个 **Settings** 页 → **Variables and Secrets** → **Add**
- 类型选 **Secret**（加密存储）
- 名字填 `REGISTER_SECRET`
- 值自己定一串随机字符，比如 `ab7f2c9e4d1`（别用这个，自己想一个）
- **这串值待会要填进 config.json，记下来**

> 没有这个暗号，任何人都能改写你桥接的指向，把手机引到别处去。

### 6. 拿到你的固定地址

Worker 页面顶部会显示，形如：

```
https://app-bridge.你的账户名.workers.dev
```

访问 `https://app-bridge.你的账户名.workers.dev/__status` 应该返回：

```json
{"ok":true,"target":null}
```

看到这个就说明 Worker 活了（`target` 是 null，因为桥接还没上报）。

### 7. 填进 config.json

打开 `app-bridge/config.json`，把 `relay` 段填上：

```json
"relay": {
  "url": "https://app-bridge.你的账户名.workers.dev",
  "secret": "你刚才设的那串暗号"
}
```

### 8. 重启桥接

双击 `start.cmd`，看到这两行就对了：

```
✓ 隧道已就绪：https://xxx.trycloudflare.com
✓ 已同步到中转：https://app-bridge.xxx.workers.dev（手机填这个就行）
```

### 9. 手机填固定地址

手机上填 **Worker 那个地址**（不是 trycloudflare 的），以后永远不用改。

---

## 出问题怎么看

| 现象 | 原因 |
|---|---|
| 访问 Worker 地址返回 `bridge not registered yet` | 桥接没启动，或 `relay.url` 填错 |
| 桥接日志出现 `中转上报被拒：HTTP 403` | `relay.secret` 和 CF 里的 `REGISTER_SECRET` 不一致 |
| 手机连不上但电脑看着正常 | 打开 `.../__status` 看 `target` 是不是当前隧道地址 |

**这不是必须的。** 等你域名实名通过、配上命名隧道（`tunnel.mode = named`）之后，
地址本来就不变了，这套中转可以直接删掉。
