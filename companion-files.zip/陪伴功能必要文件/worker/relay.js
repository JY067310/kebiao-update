// app-bridge / worker / relay.js
//
// 固定地址中转（Cloudflare Worker）
//
// 干什么：
//   手机永远只认 https://<你的>.workers.dev 这一个地址。
//   桥接每次启动把当前的 trycloudflare 隧道地址 POST 上来，存进 KV。
//   Worker 收到请求时，按 KV 里记的地址转发过去。
//
// 为什么要它：
//   trycloudflare 是临时隧道，电脑每次重启地址都变，手机就得跟着改。
//   Worker 的 workers.dev 子域名是免费且永久的，把"会变的地址"藏到后面，
//   手机侧就永远不用动。
//
// 部署后需要配两样东西（见 worker/README.md）：
//   1. KV 命名空间，绑定变量名 BRIDGE_KV
//   2. 环境变量 REGISTER_SECRET（自己定一串随机字符）
//      没这个的话，谁都能改写你桥接的指向，务必设。

const PATH_STATUS = '/__status';
const PATH_REGISTER = '/__register';
const TUNNEL_RE = /^https:\/\/[a-z0-9][a-z0-9-]*\.trycloudflare\.com$/i;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // ── 看一眼现在指向哪 ──
    if (url.pathname === PATH_STATUS) {
      const target = await env.BRIDGE_KV.get('target');
      return Response.json({ ok: true, target: target || null }, {
        headers: { 'cache-control': 'no-store' },
      });
    }

    // ── 桥接启动时上报当前隧道地址 ──
    if (url.pathname === PATH_REGISTER && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const secret = env.REGISTER_SECRET || '';
      if (!secret || body.secret !== secret) {
        return new Response('forbidden', { status: 403 });
      }
      if (!TUNNEL_RE.test(String(body.url || ''))) {
        return new Response('bad url', { status: 400 });
      }
      await env.BRIDGE_KV.put('target', body.url);
      return Response.json({ ok: true, target: body.url });
    }

    // ── 其余请求：转发到当前隧道 ──
    const target = await env.BRIDGE_KV.get('target');
    if (!target) {
      return new Response('bridge not registered yet\n', {
        status: 503,
        headers: { 'content-type': 'text/plain; charset=utf-8' },
      });
    }

    let dest;
    try {
      dest = new URL(target);
    } catch {
      return new Response('stored target is invalid\n', { status: 500 });
    }
    dest.pathname = url.pathname;
    dest.search = url.search;

    const init = {
      method: request.method,
      headers: request.headers,
      redirect: 'manual',
    };
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      init.body = request.body;
    }

    return fetch(dest.toString(), init);
  },
};
