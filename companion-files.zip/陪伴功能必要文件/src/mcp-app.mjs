#!/usr/bin/env node
// app-bridge / src/mcp-app.mjs
//
// 给 DSH 用的 MCP 工具（stdio，手写协议、零依赖）。
// 对应 qq-bridge 里的 mcp-snowluma-safe：模型输出只是思考，**发言必须调工具**。
//
//   BOT_BRIDGE_URL=http://127.0.0.1:8790 BOT_ADMIN_TOKEN=change-me-admin node src/mcp-app.mjs

const BASE = (process.env.BOT_BRIDGE_URL || 'http://127.0.0.1:8790').replace(/\/+$/, '');
const TOKEN = process.env.BOT_ADMIN_TOKEN || '';

async function call(method, path, payload) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      'content-type': 'application/json',
      ...(TOKEN ? { authorization: `Bearer ${TOKEN}` } : {}),
    },
    ...(payload ? { body: JSON.stringify(payload) } : {}),
    signal: AbortSignal.timeout(20_000),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`${res.status} ${text.slice(0, 300)}`);
  return text;
}

const TOOLS = [
  {
    name: 'app_send_message',
    description: '把一句话发给 App 里的某个会话（立即出现在对方手机上）。用于主动开口、补充消息、分条发送。',
    inputSchema: {
      type: 'object',
      properties: {
        conversationId: { type: 'string', description: '会话 ID，例如 u1' },
        text: { type: 'string', description: '要发的话，原样发送，不要加引号或旁白' },
      },
      required: ['conversationId', 'text'],
    },
  },
  {
    name: 'app_list_conversations',
    description: '列出桥接里所有会话：会话 ID、对应 DSH session、轮数、最后活跃时间。',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'app_health',
    description: '桥接与 DSH 的连通状态（DSH 是否在线、事件流是否已连）。',
    inputSchema: { type: 'object', properties: {} },
  },
];

async function run(name, args = {}) {
  switch (name) {
    case 'app_send_message':
      return call('POST', '/v1/admin/send', { conversationId: args.conversationId, text: args.text });
    case 'app_list_conversations':
      return call('GET', '/v1/admin/conversations');
    case 'app_health':
      return call('GET', '/v1/health');
    default:
      throw new Error(`未知工具：${name}`);
  }
}

// ───────────────────── MCP stdio（换行分隔 JSON-RPC）─────────────────────
const send = (msg) => process.stdout.write(JSON.stringify(msg) + '\n');

async function handle(msg) {
  const { id, method, params } = msg;

  if (method === 'initialize') {
    return send({
      jsonrpc: '2.0', id,
      result: {
        protocolVersion: params?.protocolVersion || '2024-11-05',
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: 'app-bridge', version: '0.1.0' },
      },
    });
  }
  if (method?.startsWith('notifications/')) return;
  if (method === 'ping') return send({ jsonrpc: '2.0', id, result: {} });
  if (method === 'tools/list') return send({ jsonrpc: '2.0', id, result: { tools: TOOLS } });

  if (method === 'tools/call') {
    const { name, arguments: args } = params || {};
    try {
      return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: await run(name, args) }] } });
    } catch (e) {
      return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: `调用失败：${e.message}` }], isError: true } });
    }
  }

  if (id !== undefined) send({ jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } });
}

let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  buf += chunk;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    try { void handle(JSON.parse(line)); }
    catch (e) { process.stderr.write(`bad json: ${e.message}\n`); }
  }
});
process.stdin.on('end', () => process.exit(0));
process.stderr.write(`app-bridge mcp 就绪 → ${BASE}\n`);
