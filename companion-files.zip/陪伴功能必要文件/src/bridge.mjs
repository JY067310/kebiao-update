// app-bridge / src/bridge.mjs
//
// 把「你自己的 App」接到 DeepSeek Harness —— 和 qq-bridge 同一套分层，只换传输层：
//
//   QQ 那套：  QQ ↔ SnowLuma(OneBot) ↔ qq-bridge ↔ DSH Web API ↔ 模型
//   这套：    你的 App ↔ 本文件(HTTP) ↔ DSH Web API ↔ 模型
//
// 桥接不碰模型：每条 App 消息被写成一个 DSH 会话输入（session/prompt），
// DSH 跑完一轮后把 assistant 文本从 remote.mux 事件流里取出来，放进 outbox 等 App 拉。

import http from 'node:http';
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import {
  NodeApiClient, unwrap, createTurnCollector,
  discoverDshSessionCookie, isLoopbackBase,
} from '../lib/dsh-client.js';
import { discoverDshBaseUrl } from '../lib/dsh-endpoint.js';
import { MemoryStore } from './memory.mjs';
import { AttachmentStore, buildPromptContent } from './attachments.mjs';
import { initVault, readJson, writeJson, readJsonSync } from './vault.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');

// ───────────────────────── 配置与持久化 ─────────────────────────
const cfg = JSON.parse(fsSync.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
const STATE_PATH = path.join(ROOT, 'state', 'state.json');
const USERS_PATH = path.join(ROOT, 'state', 'users.json');

// 落盘加密：密钥在 %APPDATA%/app-bridge/vault.key，不在项目目录里。
// 密钥丢了但数据还在时必须停下来 —— 用新密钥继续跑会把旧数据盖成空。
try {
  const v = initVault({ probeFiles: [STATE_PATH, USERS_PATH] });
  if (v.created) console.log(`[vault] 生成落盘加密密钥：${v.keyPath}`);
} catch (e) {
  console.error(`\n[vault] ${e.message}\n`);
  process.exit(1);
}

let state = { seq: 0, conversations: {}, outbox: [], devices: {} };
let users = [];               // { token, userId, displayName, createdAt, lastSeenAt }

// ── 人设卡 ──
// 原来只在启动时读一次，改完 md 必须重启桥接才生效 —— 而重启会换隧道地址，
// 手机那头也得跟着改，代价太大。现在改成「按 mtime 判断要不要重读」：
// 你改完文件，下一条消息就用新卡，不用重启。
let roleText = '';
let roleMtime = 0;

/**
 * 读人设卡，文件没变就用内存里那份。
 *
 * @param {boolean} force 忽略 mtime 强制重读（启动时用）
 */
async function currentRole(force = false) {
  if (cfg.role?.enabled === false) return '';
  const p = path.resolve(ROOT, cfg.role?.file || 'roles/companion.md');
  try {
    const info = await fs.stat(p);
    if (!force && roleText && info.mtimeMs === roleMtime) return roleText;
    roleText = (await fs.readFile(p, 'utf8')).trim();
    roleMtime = info.mtimeMs;
    log(`人格卡：${path.relative(ROOT, p)}（${roleText.length} 字）`);
    return roleText;
  } catch {
    log(`⚠ 人格卡读不到：${p}，会话将没有角色设定`);
    return roleText;
  }
}

async function loadState() {
  const s = await readJson(STATE_PATH, null);
  if (s) state = s;
  state.outbox ||= [];
  state.conversations ||= {};
  state.devices ||= {};
  if (typeof state.seq !== 'number') state.seq = 0;
  const u = await readJson(USERS_PATH, null);
  if (u) users = u;
  if (!Array.isArray(users)) users = [];
}

let saveChain = Promise.resolve();
function save() {
  saveChain = saveChain.then(async () => {
    await writeJson(STATE_PATH, state);
  }).catch((e) => log(`保存状态失败：${e.message}`));
  return saveChain;
}

let saveUsersChain = Promise.resolve();
function saveUsers() {
  saveUsersChain = saveUsersChain.then(async () => {
    await writeJson(USERS_PATH, users);
  }).catch((e) => log(`保存用户失败：${e.message}`));
  return saveUsersChain;
}

const log = (...a) => console.log(new Date().toISOString(), ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── 长期记忆 ──
// 每个会话一份 state/memory/<hash>.json，跟 DSH 的 sessionId 完全解耦：
// 重置会话 / 改人设 / 重启桥接都不会让她忘记你。
// ask 传入的是「开独立 DSH 会话问一句」的函数，见下面的 askDshOnce。
const memory = new MemoryStore({
  root: ROOT,
  config: cfg.memory || {},
  log,
  ask: (text, timeoutMs) => askDshOnce(text, timeoutMs),
});

// 聊天里的图片 / 文件，落在 state/uploads/
const attachments = new AttachmentStore({ root: ROOT, log });

// ───────────────────────── 用户鉴权 ─────────────────────────
/**
 * 解析 Bearer token，返回 { userId, displayName, token } 或 null。
 * 无用户记录时降级为旧版共享 token 模式（app.token）。
 */
let lastSeenSaveAt = 0;
function resolveUser(token) {
  if (!token) return null;
  const found = users.find((u) => u.token === token);
  if (found) {
    // 「最后使用」给控制台看谁在用；节流写盘，别每个请求都落一次
    found.lastSeenAt = Date.now();
    if (Date.now() - lastSeenSaveAt > 60_000) {
      lastSeenSaveAt = Date.now();
      saveUsers();
    }
    return { userId: found.userId, displayName: found.displayName, token: found.token };
  }
  // 旧版兼容：无用户记录时用 app.token 作为公用钥匙
  if (users.length === 0 && cfg.app.token && token === cfg.app.token) {
    return { userId: '_shared', displayName: 'Shared', token };
  }
  return null;
}

/**
 * 检查 conversationId 是否属于该用户。
 * 一视同仁：不管桥接只服务一个人还是一百个人，都按「会话创建时记下的 userId」判定。
 * （旧版在单用户时直接放行，等于没有边界；以后加第二个用户就会穿。）
 * 会话还没建立时，只允许建在自己名下：userId / userId:xxx / userId-xxx。
 */
function ownsConversation(userId, convId) {
  if (!convId || !userId) return false;
  const rec = state.conversations[convId];
  if (rec) return Boolean(rec.userId) && rec.userId === userId;
  return convId === userId || convId.startsWith(userId + ':') || convId.startsWith(userId + '-');
}

/** 拒绝的理由。 */
function authFail(res, msg = 'unauthorized') {
  return json(res, 401, { error: msg });
}

// ───────────────────────── 管理端鉴权 ─────────────────────────
// 三道门，缺一不可：
//   1. 必须从本机来（带 cf-connecting-ip / cf-ray 的说明是公网隧道转发过来的，一律拒）；
//   2. 要有有效的会话 cookie（登录换来的，HttpOnly，脚本读不到）；
//   3. 令牌本身只以 sha256 形式存在配置里，比对用常量时间。
// 这样就算管理令牌被人看到，他从公网也进不来；而在本机的人本来就能翻 state 目录。

const ADMIN_COOKIE = 'ab_admin_sid';
const ADMIN_TTL_MS = 2 * 60 * 60 * 1000;
const adminSessions = new Map();          // sid → 过期时间戳

const sha256hex = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

/** 配置里期望的哈希。老配置只有明文 adminToken 时，现场算一次哈希兼容。 */
function adminHashWanted() {
  const h = String(cfg.app?.adminTokenHash || '').trim().toLowerCase();
  if (/^[0-9a-f]{64}$/.test(h)) return h;
  const legacy = String(cfg.app?.adminToken || '');
  return legacy ? sha256hex(legacy) : '';
}

function tokenMatches(got) {
  const want = adminHashWanted();
  if (!want || !got) return false;         // 没配 = 不开放，绝不放行
  const a = Buffer.from(sha256hex(got), 'hex');
  const b = Buffer.from(want, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (k) out[k] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function sessionValid(req) {
  const sid = parseCookies(req)[ADMIN_COOKIE];
  if (!sid) return false;
  const exp = adminSessions.get(sid);
  if (!exp) return false;
  if (exp < Date.now()) { adminSessions.delete(sid); return false; }
  return true;
}

/** 这个请求是不是从公网隧道进来的。cloudflared 一定会加这两个头之一。 */
function fromPublicTunnel(req) {
  return Boolean(req.headers['cf-connecting-ip'] || req.headers['cf-ray']);
}

/** 是不是从本机回环连过来的（127.0.0.1 / ::1）。 */
function isLoopback(req) {
  const addr = String(req.socket?.remoteAddress || '');
  return addr === '127.0.0.1' || addr === '::1' || addr === '::ffff:127.0.0.1';
}

/**
 * 浏览器跨站请求的拦截。
 * 接口的 CORS 响应头是 `*`（App 那边要跨域），如果不拦，你随便打开一个
 * 网页，那网页里的 JS 就能 fetch 本机的 8790 把聊天读走 —— 这跟「没人能
 * 碰我电脑」是两回事，它根本不需要碰到你的电脑。
 * 带 Origin 头且来源不是本机控制台本身的，一律当成外部请求。
 */
function originOk(req) {
  const origin = String(req.headers.origin || '');
  if (!origin) return true;          // curl / App 这类非浏览器请求没有 Origin
  return /^https?:\/\/(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/i.test(origin);
}

function adminOk(req) {
  if (fromPublicTunnel(req)) return false;
  if (!originOk(req)) return false;
  // 本机直连不再要令牌：这是用户自己的电脑，控制台就在手边。
  // 从局域网 IP 或公网域名打开时，仍然走下面的会话 / 令牌校验。
  if (isLoopback(req)) return true;
  if (sessionValid(req)) return true;
  const bearer = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  return Boolean(bearer) && tokenMatches(bearer);
}

// 过期会话清一清，别让 Map 无限长
setInterval(() => {
  const now = Date.now();
  for (const [sid, exp] of adminSessions) if (exp < now) adminSessions.delete(sid);
}, 10 * 60 * 1000).unref?.();


// ───────────────────────── DSH 客户端 ─────────────────────────
const client = new NodeApiClient(cfg.dsh.baseUrl || 'http://127.0.0.1:25115', 30_000, {
  token: cfg.dsh.authToken || '',
  tokenExplicit: Boolean(cfg.dsh.authToken),
});

let baseUrl = cfg.dsh.baseUrl || 'http://127.0.0.1:25115';

async function ensureDsh() {
  if (await probe(baseUrl)) return true;
  const found = await discoverDshBaseUrl({ current: baseUrl, log });
  if (!found) return false;
  if (client.rebind(found)) baseUrl = found;
  return true;
}

async function probe(base) {
  try {
    const r = await fetch(`${base}/api/settings/describe`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(discoverDshSessionCookie(base) ? { cookie: discoverDshSessionCookie(base) } : {}),
      },
      body: JSON.stringify({ type: 'client-request', rpcId: `probe-${crypto.randomUUID()}`, method: 'settings/describe', payload: { args: {} } }),
      signal: AbortSignal.timeout(2500),
    });
    if (!r.ok) return false;
    const body = await r.json();
    return body?.result?.ok === true;
  } catch {
    return false;
  }
}

// ───────────────────────── 会话与回合 ─────────────────────────
const collectors = new Map();
const pending = new Map();
const queues = new Map();
let activeStream = null;
let streamReady = false;
let stopping = false;

function followSession(sessionId) {
  if (!sessionId) return;
  if (activeStream) activeStream.follow(sessionId);
  else client._followSession(sessionId);
}

function conv(convId) {
  state.conversations[convId] ||= { convId, sessionId: '', createdAt: Date.now(), lastSeenAt: 0, turns: 0 };
  return state.conversations[convId];
}

// ───────────────────────── 设备 → 会话 ─────────────────────────
/** deviceId 由客户端生成并长期保存；只接受干净的 ASCII，长度 8~64。 */
function validDeviceId(s) {
  return typeof s === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(s);
}

/**
 * 给一台设备分配（或取回）它专属的会话。
 * 同一 deviceId 永远拿回同一个 conversationId，重启桥接也不会变。
 */
function allocConversation(userId, deviceId, bindConversationId = '') {
  const existing = state.devices[deviceId];
  if (existing) {
    // deviceId 被人抢注：拒绝，而不是把别人的设备记录顶掉
    if (existing.userId !== userId) return { conflict: true };
    if (state.conversations[existing.conversationId]) {
      existing.lastSeenAt = Date.now();
      return { device: existing, created: false };
    }
  }
  let cid = '';
  // 老用户升级：允许第一台设备接管原来的会话，历史聊天不丢
  if (bindConversationId && !existing && ownsConversation(userId, bindConversationId)
      && state.conversations[bindConversationId]) {
    cid = bindConversationId;
  } else {
    do {
      cid = `${userId}:dev_${crypto.randomBytes(4).toString('hex')}`;
    } while (state.conversations[cid]);
  }
  const device = {
    deviceId, userId, conversationId: cid, label: '',
    createdAt: Date.now(), lastSeenAt: Date.now(),
  };
  state.devices[deviceId] = device;
  const record = conv(cid);
  record.userId = userId;
  record.lastSeenAt = Date.now();
  return { device, created: true };
}

async function ensureSession(convId) {
  const record = conv(convId);
  if (record.sessionId) return record.sessionId;

  const created = unwrap(
    await client.sessions.create({
      ...(cfg.dsh.cwd ? { cwd: cfg.dsh.cwd } : {}),
      ...(cfg.dsh.agentPreset ? { agentPreset: cfg.dsh.agentPreset } : {}),
      sessionId: `appb-${crypto.randomBytes(8).toString('hex')}`,
    }),
    'session.create',
  );
  record.sessionId = created.sessionId;
  record.createdAt = Date.now();
  await save();
  followSession(record.sessionId);
  log(`新会话 ${convId} → ${record.sessionId}（preset=${created.agentPreset ?? cfg.dsh.agentPreset ?? '默认'}）`);
  return record.sessionId;
}

async function promptOnce(convId, text, atts = []) {
  const sessionId = await ensureSession(convId);
  const record = conv(convId);
  const first = record.turns === 0;
  // 会话自己带人设就用它的（App 里每个智能体一份），没带才回落到全局那张卡。
  // 只在第一句话注入：之后靠 DSH 会话自己的上下文记住，不用每句都塞。
  // currentRole() 会比对文件修改时间，改完 md 不用重启桥接。
  const persona = String(record.persona || '').trim() || (await currentRole());

  // 长期记忆首句一定注入；之后默认每轮都带一段精简记忆。
  // 这样即使 DSH 会话被重置 / 上下文被截断，她也记得住你。
  // 没有任何记忆前缀时保持原样直接发原文，不改变既有语气。
  const wantMemory = first || memory.cfg.injectEveryTurn !== false;
  const mem = wantMemory ? memory.promptBlock(convId, text, record.userId || '') : '';
  const prefix = [];
  if (first && persona) prefix.push(persona);
  if (mem) prefix.push(mem);
  if (first) prefix.push(`现在是 ${new Date().toLocaleString('zh-CN')}。`);
  const body = prefix.length
    ? `${prefix.join('\n\n')}\n\n---\n用户说：${text}`
    : text;

  const reply = new Promise((resolve) => {
    const timer = setTimeout(() => {
      pending.delete(sessionId);
      resolve({ timedOut: true, text: '' });
    }, Number(cfg.reply.timeoutMs || 180_000));
    pending.set(sessionId, { resolve, timer, convId });
  });

  // 提交 prompt 本身必须有个上限。
  // DSH 是「一个会话串行跑」的：如果它正在处理别的长任务，这个请求会一直挂着，
  // 而下面的 reply 定时器到点也解不开 —— 结果是这条队列任务永远不结束，
  // 后面所有消息都堵在它后面，用户在手机上看到的就是「发了没反应、永远转圈」。
  let promptTimer;
  // 默认只把附件名告诉她：师大网关的 deepseek-v4-flash 不支持图片输入，
  // 硬塞 image block 会被 DSH 拒绝、整条消息没回复。换了视觉模型再开 vision。
  const vision = cfg.dsh?.vision === true;
  let content = buildPromptContent(body, atts, vision);
  const submit = (blocks) => client.sessions.prompt({ sessionId, mode: 'queue', content: blocks });
  let promptCall = submit(content);
  const promptDeadline = new Promise((_, reject) => {
    promptTimer = setTimeout(
      () => reject(new Error('session.prompt 90 秒没有返回，DSH 可能正忙或被别的会话占着')),
      90_000,
    );
  });

  try {
    try {
      unwrap(await Promise.race([promptCall, promptDeadline]), 'session.prompt');
    } catch (e) {
      // 保险：万一以后开了 vision 但模型其实不支持，自动降级，绝不让会话卡死
      const rejectedVision = /attachment-invalid|does not support image|image input/i
        .test(String(e?.message || ''));
      if (vision && content.some((b) => b.type === 'image') && rejectedVision) {
        log(`[${convId}] 当前模型不支持图片输入，已降级为文字说明`);
        content = buildPromptContent(body, atts, false);
        promptCall = submit(content);
        unwrap(await Promise.race([promptCall, promptDeadline]), 'session.prompt');
      } else {
        throw e;
      }
    }
  } catch (e) {
    clearTimeout(promptTimer);
    promptCall.catch(() => {});          // 迟到的结果没人接了，吞掉别让它变成 unhandled
    const p = pending.get(sessionId);
    if (p) { clearTimeout(p.timer); pending.delete(sessionId); }
    throw e;
  }
  clearTimeout(promptTimer);

  const result = await reply;
  record.turns += 1;
  record.lastSeenAt = Date.now();
  return result;
}

// ───────────────────── 记忆压缩用的独立 DSH 会话 ─────────────────────
// 压缩绝不能跟聊天抢同一个会话：DSH 是「一个会话串行跑」的，
// 一旦整理卡住会把用户消息全堵在后面。这里单独开一个会话，并且复用它，
// 免得每压缩一次就在 DSH 里留一个孤儿会话。
let memorySessionId = '';
let memorySessionBusy = false;

async function newMemorySession() {
  const created = unwrap(
    await client.sessions.create({
      ...(cfg.dsh.cwd ? { cwd: cfg.dsh.cwd } : {}),
      ...(cfg.dsh.agentPreset ? { agentPreset: cfg.dsh.agentPreset } : {}),
      sessionId: `memb-${crypto.randomBytes(8).toString('hex')}`,
    }),
    'session.create',
  );
  memorySessionId = created.sessionId;
  followSession(memorySessionId);
  collectors.set(memorySessionId, createTurnCollector());
  log(`记忆整理会话：${memorySessionId}`);
  return memorySessionId;
}

/**
 * 拿一段文本去问模型一次、只拿纯文本回来。
 * 复用上面那个会话；任何异常/超时都把会话作废，下次重建，绝不影响聊天主流程。
 */
async function askDshOnce(text, timeoutMs = 90_000) {
  if (memorySessionBusy) return { ok: false, error: '上一次记忆整理还没结束' };
  memorySessionBusy = true;
  let sessionId = '';
  let promptTimer;
  try {
    if (!(await ensureDsh())) return { ok: false, error: 'DSH 不在线' };
    if (!memorySessionId) await newMemorySession();
    sessionId = memorySessionId;

    const reply = new Promise((resolve) => {
      const timer = setTimeout(() => {
        pending.delete(sessionId);
        resolve({ timedOut: true, text: '' });
      }, timeoutMs);
      pending.set(sessionId, { resolve, timer, convId: '__memory__' });
    });

    const promptCall = client.sessions.prompt({
      sessionId, mode: 'queue', content: [{ type: 'text', text }],
    });
    const deadline = new Promise((_, reject) => {
      promptTimer = setTimeout(
        () => reject(new Error('记忆整理的 session.prompt 60 秒没返回')),
        Math.min(60_000, timeoutMs),
      );
    });
    try {
      unwrap(await Promise.race([promptCall, deadline]), 'session.prompt');
    } catch (e) {
      clearTimeout(promptTimer);
      promptCall.catch(() => {});
      const p = pending.get(sessionId);
      if (p) { clearTimeout(p.timer); pending.delete(sessionId); }
      throw e;
    }
    clearTimeout(promptTimer);

    const r = await reply;
    if (r.timedOut) {
      memorySessionId = '';             // 超时后会话状态不明，别再复用
      return { ok: false, error: '记忆整理超时' };
    }
    return { ok: true, text: r.text || '' };
  } catch (e) {
    memorySessionId = '';
    return { ok: false, error: e.message };
  } finally {
    if (sessionId && !memorySessionId) collectors.delete(sessionId);
    memorySessionBusy = false;
  }
}

/** 附件元信息对外只给 id/name/kind/mime/size/url，绝不把 base64 或 imageData 放进 outbox。 */
const publicAttachment = (a) => ({
  id: a.id, kind: a.kind, name: a.name, mime: a.mime, size: a.size, url: a.url,
});

function pushOutbox(convId, text, source, atts = []) {
  const item = { seq: ++state.seq, conversationId: convId, text, ts: Date.now(), source };
  if (atts.length) item.attachments = atts.map(publicAttachment);
  state.outbox.push(item);
  if (state.outbox.length > 5000) state.outbox.splice(0, state.outbox.length - 5000);
  void save();
  return item;
}

const inflight = new Map();

function enqueue(convId, task) {
  const max = Number(cfg.app?.maxQueuePerConversation ?? 5);
  const n = inflight.get(convId) ?? 0;
  if (n >= max) return null;

  inflight.set(convId, n + 1);
  const prev = queues.get(convId) || Promise.resolve();
  const next = prev
    .then(task)
    .catch((e) => log(`[${convId}] 处理失败：${e.message}`))
    .finally(() => { inflight.set(convId, Math.max(0, (inflight.get(convId) ?? 1) - 1)); });
  queues.set(convId, next);
  return next;
}

// ───────────────────────── 事件流 ─────────────────────────
async function runEventStream() {
  while (!stopping) {
    try {
      const stream = client.openRemoteEventStream(undefined, () => {
        streamReady = true;
        log('事件流已连上');
        for (const c of Object.values(state.conversations)) {
          if (c.sessionId) stream.follow(c.sessionId);
        }
        // 事件流重连后，记忆整理那个会话也得重新 follow，否则压缩永远等不到回复
        if (memorySessionId) stream.follow(memorySessionId);
      });
      activeStream = stream;

      for await (const envelope of stream) {
        const payload = envelope?.payload;
        if (!payload) continue;
        if (payload.type === 'stream/error') {
          log(`会话流错误：${payload.error?.code ?? 'unknown'}`);
          continue;
        }
        if (payload.type !== 'session/event') continue;

        const { sessionId, event } = payload;
        collectors.set(sessionId, collectors.get(sessionId) || createTurnCollector());
        const done = collectors.get(sessionId).push(event);
        if (!done) continue;

        const waiting = pending.get(sessionId);
        if (!waiting) continue;
        pending.delete(sessionId);
        clearTimeout(waiting.timer);
        waiting.resolve({ timedOut: false, text: done.text, reason: done.reason });
      }
    } catch (e) {
      log(`事件流中断：${e.message}`);
    }
    activeStream = null;
    streamReady = false;
    if (stopping) break;
    await sleep(2000);
  }
}

// ───────────────────────── HTTP ─────────────────────────
const json = (res, code, body) => {
  const data = JSON.stringify(body);
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(data),
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'authorization,content-type',
    'access-control-allow-methods': 'GET,POST,OPTIONS',
  });
  res.end(data);
};

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/** inbox 要收 base64 图片/文件，单独放宽上限；其它接口仍按 2MB 卡住。 */
async function readBody(req, maxBytes = 2_000_000) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > maxBytes) throw new Error('请求体过大');
    chunks.push(c);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const route = `${req.method} ${url.pathname}`;
  if (req.method === 'OPTIONS') return json(res, 204, {});

  try {
    // ── 控制台（SnowLuma 风格 WebUI）──
    // 页面本身不含任何敏感数据；所有数据都走带管理令牌的 /v1/admin/status。
    if (route === 'GET /') {
      let html;
      try {
        html = fsSync.readFileSync(path.join(ROOT, 'web', 'index.html'), 'utf8');
      } catch {
        html = '<!doctype html><meta charset="utf-8"><h1>控制台文件缺失：web/index.html</h1>';
      }
      res.writeHead(200, {
        'content-type': 'text/html; charset=utf-8',
        'content-length': Buffer.byteLength(html),
        'cache-control': 'no-store',
        'x-frame-options': 'SAMEORIGIN',
      });
      return res.end(html);
    }

    if (route === 'GET /v1/health') {
      return json(res, 200, {
        ok: true,
        dsh: baseUrl,
        dshOnline: await probe(baseUrl),
        streamReady,
        conversations: Object.keys(state.conversations).length,
        users: users.length,
      });
    }

    // ── App 接口：每个请求走用户鉴权 ──
    const user = resolveUser(String(req.headers.authorization || '').replace(/^Bearer\s+/i, ''));

    // App 发来一条消息
    if (route === 'POST /v1/inbox') {
      if (!user) return authFail(res);
      const body = await readBody(req, 25_000_000);
      const { conversationId, text } = body;
      const rawText = typeof text === 'string' ? text.trim() : '';
      const hasAttachments = Array.isArray(body.attachments) && body.attachments.length > 0;
      let convId = conversationId;
      // 带 deviceId 时以服务端分配的会话为准，客户端传的 conversationId 直接忽略
      if (body.deviceId) {
        const did = String(body.deviceId).trim();
        if (!validDeviceId(did)) return json(res, 400, { error: 'deviceId 格式不对' });
        const got = allocConversation(user.userId, did);
        if (got.conflict) return json(res, 409, { error: '这个 deviceId 已被其他用户占用' });
        convId = got.device.conversationId;
      }
      if (!convId || (!rawText && !hasAttachments)) {
        return json(res, 400, { error: '需要 conversationId，以及 text 或附件' });
      }
      // 关掉自定义会话后，没带 deviceId 的普通用户只能往自己已分配的会话里发
      if (cfg.app.allowCustomConversation === false && !body.deviceId) {
        const mine = Object.values(state.devices).some(
          (d) => d.userId === user.userId && d.conversationId === convId,
        );
        if (!mine) return json(res, 403, { error: '这个会话没有分配给任何设备，请用设备会话' });
      }
      if (!ownsConversation(user.userId, convId)) {
        return json(res, 403, { error: 'conversationId 不属于该用户' });
      }
      const record = conv(convId);
      record.userId = user.userId;
      record.lastSeenAt = Date.now();

      // ── 人设 ──
      // App 每个智能体可以带自己的一份人设（body.persona）。
      // 人设是「会话第一句话」时注入的，所以一旦变了就必须重开会话 ——
      // 否则 DSH 那边的上下文里还是旧人设，改了等于没改。
      // 旧聊天记录仍然留在 outbox（App 本地照样看得到），只是 AI 不再记得。
      if (typeof body.persona === 'string') {
        const next = body.persona.trim().slice(0, 8000);
        if (next !== String(record.persona || '').trim()) {
          record.persona = next;
          record.sessionId = '';
          record.turns = 0;
          log(`[${convId}] 人设${next ? `已更新（${next.length} 字）` : '已清空，回到默认'}，会话重开`);
        }
      }

      // 附件先落盘：图片同时会作为视觉内容块喂给 DSH，文件只转文字说明。
      const stored = hasAttachments ? await attachments.store(convId, body.attachments) : [];
      // 只发附件不写字时给个占位，否则空文本会被 App 的历史过滤掉。
      const echoText = rawText ? rawText.slice(0, 4000) : '[附件]';

      // 用户这句话也存进 outbox（source=user）：App 重启后自己的气泡才不会消失。
      // 必须排在 enqueue 之前，保证 seq 顺序是「我说的话 → ta 的回复」。
      pushOutbox(convId, echoText, 'user', stored);
      memory.recordUser(convId, echoText, user.userId);
      const queued = enqueue(convId, async () => {
        const r = await promptOnce(convId, rawText || '（对方发来了附件）', stored);
        if (r.timedOut) {
          log(`[${convId}] 回合超时（${cfg.reply.onTimeout}）`);
          if (cfg.reply.onTimeout === 'fallback') {
            pushOutbox(convId, cfg.reply.fallbackText || '我这会儿有点走神，等下再说。', 'timeout');
          }
          return;
        }
        const clean = (r.text || '').trim();
        if (!clean) return;
        pushOutbox(convId, clean.slice(0, Number(cfg.reply.maxChars || 4000)), 'auto');
        memory.recordAssistant(convId, clean, record.userId || '');
      });
      if (!queued) return json(res, 429, { error: '这个会话还有消息在排队，稍等一下' });
      return json(res, 202, { ok: true, accepted: true });
    }

    // App 拉回复（含主动消息）
    if (route === 'GET /v1/outbox') {
      if (!user) return authFail(res);
      const convId = url.searchParams.get('conversationId') || '';
      if (!ownsConversation(user.userId, convId)) {
        return json(res, 403, { error: 'conversationId 不属于该用户' });
      }
      const since = Number(url.searchParams.get('since') || 0);
      const fresh = state.outbox.filter((m) => m.conversationId === convId && m.seq > since);
      // 只在真的拉到新消息时记一笔，方便排查「App 没收到」是服务端没返回还是客户端没处理
      if (fresh.length) log(`[${convId}] outbox since=${since} → ${fresh.length} 条（seq ${fresh.map((m) => m.seq).join(',')}）`);
      return json(res, 200, { messages: fresh, cursor: fresh.at(-1)?.seq ?? since });
    }

    // 用户状态
    if (route === 'GET /v1/state') {
      if (!user) return authFail(res);
      const convId = url.searchParams.get('conversationId') || user.userId;
      if (!ownsConversation(user.userId, convId)) {
        return json(res, 403, { error: 'conversationId 不属于该用户' });
      }
      const record = state.conversations[convId];
      return json(res, 200, {
        userId: user.userId,
        conversationId: convId,
        displayName: user.displayName,
        turns: record?.turns ?? 0,
        lastSeenAt: record?.lastSeenAt ?? 0,
        createdAt: record?.createdAt ?? 0,
        // App「只清显示」时用它把游标推到最新：旧消息不再拉回，服务端一条没删
        latestSeq: state.seq,
      });
    }

    // App 查看「她记住了什么」：只用用户令牌，且只能看自己会话那一份。
    if (route === 'GET /v1/memory') {
      if (!user) return authFail(res);
      const convId = url.searchParams.get('conversationId') || '';
      if (!ownsConversation(user.userId, convId)) {
        return json(res, 403, { error: 'conversationId 不属于该用户' });
      }
      // memory.get 会按 userId 校验归属：不是他的记忆直接当空处理
      if (memory.cfg.enabled && !memory.get(convId, user.userId)) {
        return json(res, 200, { ok: true, memory: null });
      }
      const d = memory.describe(convId);
      return json(res, 200, {
        ok: true,
        memory: d ? {
          conversationId: d.conversationId,
          portrait: d.portrait,
          core: d.core,
          faintCount: d.faintCount,
          faintSample: d.faintSample,
          stats: {
            compressCount: d.stats.compressCount,
            lastCompressedAt: d.stats.lastCompressedAt,
            lastNote: d.stats.lastNote,
          },
        } : null,
      });
    }

    // 下载聊天里的图片 / 文件。文件名里带 conversationId 的哈希，
    // 就算别人猜到附件 id，换个会话也拼不出同一个路径。
    if (route.startsWith('GET /v1/attachment/')) {
      if (!user) return authFail(res);
      const id = url.pathname.slice('/v1/attachment/'.length);
      const convId = url.searchParams.get('conversationId') || '';
      if (!ownsConversation(user.userId, convId)) {
        return json(res, 403, { error: 'conversationId 不属于该用户' });
      }
      const found = await attachments.open(convId, id);
      if (!found) return json(res, 404, { error: '附件不存在' });
      const safe = String(found.name).replace(/["\r\n]/g, '_');
      res.writeHead(200, {
        'content-type': found.mime,
        'content-length': found.bytes.length,
        'content-disposition': `inline; filename*=UTF-8''${encodeURIComponent(safe)}`,
        'cache-control': 'private, max-age=86400',
        'x-content-type-options': 'nosniff',
        'access-control-allow-origin': '*',
      });
      return res.end(found.bytes);
    }

    // 设备领号：App 首次连接时调一次，把返回的 conversationId 存本地，之后一直用
    if (route === 'POST /v1/session/alloc') {
      if (!user) return authFail(res);
      const body = await readBody(req);
      const raw = String(body.deviceId || '').trim();
      if (raw && !validDeviceId(raw)) {
        return json(res, 400, { error: 'deviceId 只能用字母、数字、下划线、连字符，8~64 位' });
      }
      const deviceId = raw || crypto.randomBytes(12).toString('hex');
      const got = allocConversation(user.userId, deviceId, String(body.bindConversationId || '').trim());
      if (got.conflict) return json(res, 409, { error: '这个 deviceId 已被其他用户占用，请换一个' });
      const { device, created } = got;
      if (body.label) device.label = String(body.label).slice(0, 40);
      await save();
      return json(res, 200, {
        ok: true, created, deviceId,
        conversationId: device.conversationId, userId: user.userId,
      });
    }

    // ── 管理接口 ──
    // 登录：令牌换一个 HttpOnly 会话 cookie。明文令牌只在这一步出现，
    // 之后浏览器不持有它，URL 和历史记录里也不会留下 ?token=xxx。
    if (route === 'POST /v1/admin/login') {
      if (fromPublicTunnel(req)) return json(res, 403, { error: '管理接口只允许本机访问' });
      if (!originOk(req)) return json(res, 403, { error: '不允许跨站登录' });
      const body = await readBody(req);
      if (!tokenMatches(String(body.token || '').trim())) {
        await sleep(500);                    // 拖一下，别让人坐在那儿快速试
        return json(res, 401, { error: '管理令牌不对' });
      }
      const sid = crypto.randomBytes(24).toString('base64url');
      adminSessions.set(sid, Date.now() + ADMIN_TTL_MS);
      res.setHeader('set-cookie', `${ADMIN_COOKIE}=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${ADMIN_TTL_MS / 1000}`);
      log('管理端：本机登录成功');
      return json(res, 200, { ok: true, expiresIn: ADMIN_TTL_MS / 1000 });
    }

    if (route === 'POST /v1/admin/logout') {
      const sid = parseCookies(req)[ADMIN_COOKIE];
      if (sid) adminSessions.delete(sid);
      res.setHeader('set-cookie', `${ADMIN_COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`);
      return json(res, 200, { ok: true });
    }

    if (route === 'GET /v1/admin/session') {
      return json(res, 200, { ok: adminOk(req), local: !fromPublicTunnel(req) });
    }

    // 控制台汇总：一次拿全，前端每 3 秒只打这一个接口
    if (route === 'GET /v1/admin/status') {
      if (!adminOk(req)) return authFail(res);
      let tunnelUrl = '';
      try { tunnelUrl = fsSync.readFileSync(path.join(ROOT, 'state', 'tunnel-url.txt'), 'utf8').trim(); } catch { /* 没开隧道 */ }
      const logFile = path.join(ROOT, 'logs', `bridge-${new Date().toISOString().slice(0, 10)}.log`);
      let logTail = [];
      try { logTail = fsSync.readFileSync(logFile, 'utf8').split(/\r?\n/).filter(Boolean).slice(-300); } catch { /* 今天还没日志 */ }
      const sec = Math.floor(process.uptime());
      const uptime = sec < 3600
        ? `${Math.floor(sec / 60)} 分 ${sec % 60} 秒`
        : `${Math.floor(sec / 3600)} 小时 ${Math.floor((sec % 3600) / 60)} 分`;
      return json(res, 200, {
        ok: true,
        now: Date.now(),
        pid: process.pid,
        port: Number(cfg.app?.port || 8790),
        uptime,
        dsh: { baseUrl, online: await probe(baseUrl) },
        streamReady,
        tunnelUrl,
        tunnelAlive: !!tunnelUrl,
        users,
        // 与 /v1/admin/conversations 保持同一套字段名，控制台统一按 conversationId 读
        conversations: Object.values(state.conversations).map((c) => ({
          conversationId: c.convId, sessionId: c.sessionId, userId: c.userId || null,
          turns: c.turns, createdAt: c.createdAt, lastSeenAt: c.lastSeenAt,
        })),
        devices: Object.values(state.devices),
        outbox: state.outbox.slice(-300),
        outboxCount: state.outbox.length,
        recent: state.outbox.slice(-8),
        memory: {
          enabled: Boolean(memory.cfg.enabled),
          dir: memory.cfg.dir,
          compressAfterUserTurns: Number(memory.cfg.compressAfterUserTurns),
          conversations: memory.list().map((id) => {
            const d = memory.describe(id);
            return {
              conversationId: id,
              coreCount: d.core.length,
              faintCount: d.faintCount,
              bufferCount: d.bufferCount,
              compressCount: d.stats.compressCount,
              lastCompressedAt: d.stats.lastCompressedAt,
              lastError: d.stats.lastError,
            };
          }),
        },
        config: {
          agentPreset: cfg.dsh?.agentPreset || '默认',
          cwd: cfg.dsh?.cwd || '',
          roleEnabled: cfg.role?.enabled !== false,
          roleFile: cfg.role?.file || '',
          replyTimeoutMs: Number(cfg.reply?.timeoutMs || 180000),
          maxChars: Number(cfg.reply?.maxChars || 4000),
          onTimeout: cfg.reply?.onTimeout || 'silent',
        },
        logTail,
        logFile,
      });
    }

    if (route === 'GET /v1/admin/users') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      return json(res, 200, {
        users: users.map((u) => ({
          userId: u.userId,
          displayName: u.displayName,
          createdAt: u.createdAt,
          lastSeenAt: u.lastSeenAt,
        })),
      });
    }

    if (route === 'POST /v1/admin/users') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { displayName = 'User', userId: customUserId } = await readBody(req);
      const userId = String(customUserId || '').trim() || `u_${crypto.randomBytes(6).toString('hex')}`;
      // userId 是会话 ID 的前缀，必须是干净的 ASCII：字母/数字/下划线/连字符
      if (!/^[A-Za-z0-9_-]{1,24}$/.test(userId)) {
        return json(res, 400, { error: 'userId 只能用字母、数字、下划线、连字符，1~24 位' });
      }
      const token = crypto.randomBytes(18).toString('base64url');
      if (users.some((u) => u.userId === userId)) {
        return json(res, 409, { error: `userId "${userId}" 已存在` });
      }
      users.push({ token, userId, displayName: String(displayName).trim() || userId, createdAt: Date.now(), lastSeenAt: 0 });
      await saveUsers();
      return json(res, 200, { ok: true, userId, displayName, token });
    }

    if (route === 'DELETE /v1/admin/users') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { userId } = await readBody(req);
      if (!userId) return json(res, 400, { error: '需要 userId' });
      const idx = users.findIndex((u) => u.userId === userId);
      if (idx < 0) return json(res, 404, { error: '用户不存在' });
      const removed = users.splice(idx, 1)[0];
      // 连带清掉他的会话与消息：否则以后重建同名用户（拿到新令牌）会读回旧聊天
      const doomed = new Set(
        Object.values(state.conversations).filter((c) => c.userId === userId).map((c) => c.convId),
      );
      for (const cid of doomed) delete state.conversations[cid];
      // 删用户时连他的长期记忆一起清掉：那是最私人的东西，不能留给同名新用户。
      // clearByUser 还会扫掉「会话已删但记忆文件还在」的孤儿文件。
      const droppedMemories = await memory.clearByUser(userId);
      for (const cid of doomed) await attachments.clearConversation(cid);
      if (doomed.size) state.outbox = state.outbox.filter((m) => !doomed.has(m.conversationId));
      // 他名下的设备也一并解绑，否则设备下次还能领回同一个会话
      let droppedDevices = 0;
      for (const [did, d] of Object.entries(state.devices)) {
        if (d.userId === userId) { delete state.devices[did]; droppedDevices++; }
      }
      await saveUsers();
      if (doomed.size) await save();
      return json(res, 200, {
        ok: true, userId: removed.userId, token: removed.token,
        droppedConversations: doomed.size, droppedDevices, droppedMemories,
      });
    }

    // 解绑一台设备：连带清掉它独占的会话与消息（设备下次连会领到新的）
    if (route === 'DELETE /v1/admin/devices') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { deviceId } = await readBody(req);
      const device = state.devices[deviceId];
      if (!device) return json(res, 404, { error: '设备不存在' });
      delete state.devices[deviceId];
      const cid = device.conversationId;
      const stillUsed = Object.values(state.devices).some((d) => d.conversationId === cid);
      if (!stillUsed) {
        delete state.conversations[cid];
        state.outbox = state.outbox.filter((m) => m.conversationId !== cid);
        await memory.clear(cid);
        await attachments.clearConversation(cid);
      }
      await save();
      return json(res, 200, {
        ok: true, deviceId, conversationId: cid, removedConversation: !stillUsed,
      });
    }

    // 删掉一条会话（连带消息、解绑指向它的设备）：清理废弃会话/孤儿会话用
    if (route === 'DELETE /v1/admin/conversations') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { conversationId } = await readBody(req);
      if (!conversationId) return json(res, 400, { error: '需要 conversationId' });
      const existed = Boolean(state.conversations[conversationId]);
      delete state.conversations[conversationId];
      await memory.clear(conversationId);
      await attachments.clearConversation(conversationId);
      const before = state.outbox.length;
      state.outbox = state.outbox.filter((m) => m.conversationId !== conversationId);
      let unbound = 0;
      for (const [did, d] of Object.entries(state.devices)) {
        if (d.conversationId === conversationId) { delete state.devices[did]; unbound++; }
      }
      await save();
      return json(res, 200, {
        ok: true, conversationId, existed,
        removedMessages: before - state.outbox.length, unboundDevices: unbound,
      });
    }

    // 删掉单条消息（清理测试消息、误发消息）
    if (route === 'DELETE /v1/admin/messages') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { seq } = await readBody(req);
      const n = Number(seq);
      if (!n) return json(res, 400, { error: '需要 seq' });
      const before = state.outbox.length;
      state.outbox = state.outbox.filter((m) => m.seq !== n);
      await save();
      return json(res, 200, { ok: true, seq: n, removed: before - state.outbox.length });
    }

    if (route === 'GET /v1/admin/conversations') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      return json(res, 200, {
        conversations: Object.values(state.conversations).map((c) => ({
          conversationId: c.convId, sessionId: c.sessionId, userId: c.userId || null,
          turns: c.turns, createdAt: c.createdAt, lastSeenAt: c.lastSeenAt,
        })),
      });
    }

    if (route === 'POST /v1/admin/send') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { conversationId, text, source } = await readBody(req);
      if (!conversationId || typeof text !== 'string' || !text.trim()) {
        return json(res, 400, { error: '需要 conversationId 和 text' });
      }
      // source=user 仅用于控制台调试（伪造一条「我发的」消息，验证回显/持久化）
      const kind = source === 'user' ? 'user' : 'manual';
      const item = pushOutbox(conversationId, text.trim(), kind);
      return json(res, 200, { ok: true, seq: item.seq, source: kind });
    }

    if (route === 'POST /v1/admin/reset') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { conversationId } = await readBody(req);
      const record = state.conversations[conversationId];
      if (record) {
        record.sessionId = '';
        record.turns = 0;
        await save();
      }
      // 只重置对话上下文，长期记忆保留 —— 这正是「她不会忘了我」的关键
      return json(res, 200, { ok: true, memoryKept: Boolean(memory.cfg.enabled) });
    }

    // ── 长期记忆管理 ──
    if (route === 'GET /v1/admin/memory') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const cid = url.searchParams.get('conversationId') || '';
      if (cid) {
        const d = memory.describe(cid);
        return d ? json(res, 200, { ok: true, memory: d }) : json(res, 404, { error: '没有这个会话的记忆' });
      }
      return json(res, 200, {
        ok: true, enabled: Boolean(memory.cfg.enabled),
        memories: memory.list().map((id) => {
          const d = memory.describe(id);
          return {
            conversationId: id,
            coreCount: d.core.length,
            faintCount: d.faintCount,
            bufferCount: d.bufferCount,
            compressCount: d.stats.compressCount,
            lastCompressedAt: d.stats.lastCompressedAt,
            lastError: d.stats.lastError,
          };
        }),
      });
    }

    if (route === 'POST /v1/admin/memory/compress') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { conversationId, force = true } = await readBody(req);
      if (!conversationId) return json(res, 400, { error: '需要 conversationId' });
      const ok = await memory.compress(conversationId, { force: Boolean(force) });
      return json(res, 200, { ok, memory: memory.describe(conversationId) });
    }

    if (route === 'POST /v1/admin/memory/pin') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { conversationId, text } = await readBody(req);
      if (!conversationId || typeof text !== 'string' || !text.trim()) {
        return json(res, 400, { error: '需要 conversationId 和 text' });
      }
      const item = await memory.pin(conversationId, text);
      return json(res, 200, { ok: true, item });
    }

    if (route === 'DELETE /v1/admin/memory') {
      if (!adminOk(req)) return json(res, 401, { error: 'unauthorized' });
      const { conversationId, id } = await readBody(req);
      if (!conversationId) return json(res, 400, { error: '需要 conversationId' });
      if (id !== undefined && memory.describe(conversationId)) {
        const removed = await memory.unpin(conversationId, id);
        return json(res, 200, { ok: true, removedCore: removed });
      }
      await memory.clear(conversationId);
      return json(res, 200, { ok: true, cleared: true });
    }

    return json(res, 404, { error: 'not found' });
  } catch (e) {
    log(`请求失败 ${route}：${e.message}`);
    return json(res, 500, { error: e.message });
  }
});

// ───────────────────────── 启动 ─────────────────────────
await loadState();

// 从环境变量推送一个初始用户（启动器会在首次运行时设置）
// 必须在「补归属」之前：迁移要靠 users 才知道该归给谁。
if (process.env.APP_BRIDGE_INIT_USER_ID && process.env.APP_BRIDGE_INIT_TOKEN) {
  if (!users.some((u) => u.userId === process.env.APP_BRIDGE_INIT_USER_ID)) {
    users.push({
      token: process.env.APP_BRIDGE_INIT_TOKEN,
      userId: process.env.APP_BRIDGE_INIT_USER_ID,
      displayName: process.env.APP_BRIDGE_INIT_DISPLAY || process.env.APP_BRIDGE_INIT_USER_ID,
      createdAt: Date.now(),
      lastSeenAt: 0,
    });
    void saveUsers();
  }
}

// 老版本的会话没记 userId（那时单用户不需要边界）。现在校验是严格的，
// 不补的话 App 会突然全部 403 —— 所以在这里一次性归给唯一的用户。
if (users.length === 1) {
  let adopted = 0;
  for (const c of Object.values(state.conversations)) {
    if (!c.userId) { c.userId = users[0].userId; adopted += 1; }
  }
  if (adopted) {
    await save();
    log(`会话归属：${adopted} 个历史会话已归到 ${users[0].userId}`);
  }
} else if (users.length > 1) {
  const orphans = Object.values(state.conversations).filter((c) => !c.userId);
  if (orphans.length) {
    log(`⚠ 有 ${orphans.length} 个会话没有归属（多用户下无法自动判断），普通用户访问会被拒绝`);
  }
}

// 把 state.json 里记着的会话归属交给记忆模块：老版本记忆文件靠这个补上 userId，
// 对不上的残留文件会被标成「无归属」并拒绝一切普通用户访问。
const memoryOwners = {};
for (const [cid, c] of Object.entries(state.conversations)) {
  if (c.userId) memoryOwners[cid] = c.userId;
}
await memory.init(memoryOwners);
await attachments.init();

// 不论上面有没有迁移，都重写一遍：老版本的明文 state/users 会在这里变成密文。
await save();
await saveUsers();

// 启动时先读一次，把 mtime 记下来；之后每次发消息再按 mtime 判断要不要重读。
await currentRole(true);

if (!(await ensureDsh())) {
  log('⚠ 找不到 DSH。确认 DSH 正在运行，或在 config.json 里写死 dsh.baseUrl。');
} else {
  log(`DSH：${baseUrl}${isLoopbackBase(baseUrl) ? '（本机）' : ''}`);
}
log(`离线 Cookie：${discoverDshSessionCookie(baseUrl) ? '可用' : '不可用（需要 DSH 在本机跑过一次）'}`);
log(`用户鉴权：${users.length > 0 ? `${users.length} 个用户` : '旧版共享 token 模式（无独立用户记录）'}`);

void runEventStream();

let lastDshOnline = null;
setInterval(async () => {
  if (stopping) return;
  const online = await probe(baseUrl);
  if (online) {
    if (lastDshOnline === false) log(`DSH 恢复：${baseUrl}`);
    lastDshOnline = true;
    return;
  }
  if (lastDshOnline !== false) log('DSH 失联，正在重新发现端点…');
  lastDshOnline = false;
  const found = await discoverDshBaseUrl({ current: baseUrl, log: () => {} });
  if (found && client.rebind(found)) {
    baseUrl = found;
    log(`DSH 端点已更新 → ${found}`);
  }
}, 30_000);

// 记忆压缩定时巡检：只挑「聊完停了一会儿、且没有消息在排队」的会话，
// 一次只跑一份，全程异步，绝不占聊天队列。失败会留着 buffer 下次重试。
if (memory.cfg.enabled) {
  const interval = Math.max(30_000, Number(memory.cfg.compressIntervalMs) || 300_000);
  const sweep = () => { if (!stopping) void memory.tick((cid) => (inflight.get(cid) ?? 0) > 0); };
  setInterval(sweep, interval);
  // 重启后先补跑一次：上次没来得及压缩的对话，别一直躺在 buffer 里
  setTimeout(sweep, 8_000);
  log(`记忆压缩巡检：每 ${Math.round(interval / 1000)} 秒一次`);
}

server.listen(Number(cfg.app?.port || 8790), '0.0.0.0', () => {
  log(`app-bridge 监听 http://localhost:${cfg.app?.port || 8790}`);
  log(`App 侧：POST /v1/inbox ｜ GET /v1/outbox ｜ GET /v1/state`);
  log(`管理侧：GET/POST /v1/admin/users ｜ POST /v1/admin/send`);
  if (users.length === 0) log('⚠ 尚无用户。用管理令牌创建用户：curl -X POST .../v1/admin/users -H "Authorization: Bearer $ADMIN_TOKEN"');
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, async () => {
    stopping = true;
    log('退出中…');
    await save();
    await saveUsers();
    if (memory.cfg.enabled) await Promise.all(memory.list().map((id) => memory.save(id)));
    process.exit(0);
  });
}
