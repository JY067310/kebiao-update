// app-bridge / src/memory.mjs
//
// 小娅自己的长期记忆。和 DSH 的会话上下文彻底解耦：
//   - 会话上下文：DSH 管，sessionId 一变就忘光；
//   - 长期记忆：本文件管，落在 state/memory/*.json，重置会话 / 重启桥接 / 改人设都不丢。
//
// 三层结构（用户要求「重要的不压缩，压缩的也要有印象」）：
//   portrait  关于对方的整体画像，保留名字、身份、关系、重要经历等锚点；
//   core      她判定为重要的事实，**原话保留**，永不参与压缩；
//   faint     被压缩掉的琐碎内容，只留一句淡淡线索，聊到相关话题时能重新浮上来。
//
// 「谁来判断什么重要」交给模型自己：压缩时把旧的 core / faint / 新对话全给它，
// 让它全量重写三层。桥接只做三件事：格式校验、重要事实兜底（防止模型手滑丢掉）、
// 把 faint 压缩成可检索的线索。不写死「什么算重要」的规则。
//
// 压缩跑在独立的 DSH 会话里、完全异步，绝不占用聊天会话的队列。

import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { readJson, writeJson, readBytes, isSealed } from './vault.mjs';

export const MEMORY_DEFAULTS = {
  enabled: true,
  dir: 'state/memory',
  maxCoreFacts: 40,
  maxFaint: 160,
  portraitMaxChars: 900,
  injectEveryTurn: true,
  compressAfterUserTurns: 8,
  compressIdleMs: 20_000,
  compressIntervalMs: 60_000,
  compressMaxAgeMs: 6 * 60 * 60 * 1000,
  compressTimeoutMs: 90_000,
  maxBufferItems: 40,
  promptMaxChars: 7_000,
  faintRecallTopK: 6,
  faintRecentTopK: 4,
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ───────────────────────── 文本相似度 ─────────────────────────
// 中文二元组 + 英文单词，够用且不引依赖。用来判断：
//   ① 一条旧 core 是被「改写更新」了（相似度高）还是被「误删」了（相似度低）；
//   ② 当前这句话和哪几条 faint 印象有关。
function tokenize(text) {
  const s = String(text ?? '').toLowerCase();
  const out = new Set();
  for (const w of s.match(/[a-z0-9_]{2,}/g) ?? []) out.add(w);
  const cjk = s.replace(/[^\u4e00-\u9fff]/g, '');
  for (let i = 0; i < cjk.length - 1; i += 1) out.add(cjk.slice(i, i + 2));
  if (cjk.length === 1) out.add(cjk);
  return out;
}

export function similarity(a, b) {
  const x = tokenize(a);
  const y = tokenize(b);
  if (!x.size || !y.size) return 0;
  let hit = 0;
  for (const t of x) if (y.has(t)) hit += 1;
  return hit / (x.size + y.size - hit);
}

/** 交集 / 较短一方，短句改写时比 Jaccard 稳。 */
function overlap(a, b) {
  const x = tokenize(a);
  const y = tokenize(b);
  if (!x.size || !y.size) return 0;
  let hit = 0;
  for (const t of x) if (y.has(t)) hit += 1;
  return hit / Math.min(x.size, y.size);
}

/**
 * 判断一条旧 core 是被「改写更新」了，还是被模型手滑删了。
 * 中文短句改写（「在准备期末考试」→「考完了」）Jaccard 往往只有 0.25 左右，
 * 阈值定太高会把新旧两条并存，反而把记忆弄脏。
 */
function looksLikeRewrite(oldText, newText) {
  return similarity(oldText, newText) > 0.2 || overlap(oldText, newText) > 0.55;
}

function normalize(text) {
  return String(text ?? '')
    .replace(/[\s，。、！？,.!?；;：:"'“”‘’（）()\[\]【】~—-]/g, '')
    .toLowerCase();
}

function clampText(text, max) {
  const s = String(text ?? '').replace(/\s+/g, ' ').trim();
  return s.length > max ? `${s.slice(0, max)}…` : s;
}

// ───────────────────────── 压缩提示词 ─────────────────────────
// 注意：判断权明确交给她自己，不给「什么算重要」的硬规则表。
const COMPRESS_INSTRUCTION = `你是「小娅」的记忆整理助手。你现在在整理自己记住的、关于「对方」的事。

请你自己判断轻重：
- 关于对方本人、长期成立、弄错了会很伤人的 —— 身份、名字、你们的关系、他在意的人、偏好与禁忌、正在经历的大事、你答应过他的事、他反复提起的东西 —— 放进 keep，尽量用原来的话，不要改写、不要概括。
- 只是一时闲聊、随口一提、情绪过去就散了的 —— 不要直接扔掉，压成一句淡淡的线索放进 faint，让你以后聊到相关话题还能隐约想起来「好像有过这么回事」。
- 重复、过时、说错了的，合并或更正。但名字、身份、关系、约定这些锚点必须在 portrait 里留着。
- portrait 是你对他的整体印象，写第二人称无关，用「对方」指代即可，别写成条目清单。

两条很重要的边界：
1. **只有 [对方] 说的话才是关于他的信息。** [你] 说的话是你自己的猜测、关心、玩笑、提议或随口编的细节，除非对方明确回应确认了，否则绝不能写成「他已经如何如何」的事实。把你自己说过的话当成他的经历，是最容易犯的错。
2. 如果发现以前记错了、或者某件事已经过时，把那条的原文放进 drop 并写清原因。放进 drop 的不会再被兜底找回；没放进去的，就算你这次漏写，系统也会替你补回来。

只输出一个 JSON 对象，不要任何解释、不要 markdown 代码块：
{
  "portrait": "整体印象，300 字以内",
  "keep": [{"text": "一条你决定长期清楚记得的事", "importance": 5}],
  "faint": [{"hint": "一句模糊线索，别写成确凿事实"}],
  "drop": [{"text": "要删掉的旧条目原文", "why": "为什么删"}],
  "note": "一句话说明你这次怎么判断的"
}

keep 与 faint 都要给「全量」（包含下面已有的、你决定继续留着的），不是只给新增的。
drop 只给确实要删掉的，没有就给空数组。importance 用 1 到 5 的整数。`;

export function buildCompressPrompt(data, maxChars) {
  const lines = [COMPRESS_INSTRUCTION, '', '【你现在的整体印象】', data.portrait || '（还没有）', '', '【你一直清楚记得的事】'];
  if (data.core.length) {
    for (const f of data.core) lines.push(`${f.id}. ${f.text}`);
  } else lines.push('（还没有）');

  lines.push('', '【你只剩模糊印象的事】');
  if (data.faint.length) {
    for (const f of data.faint) lines.push(`- ${f.hint}`);
  } else lines.push('（还没有）');

  lines.push('', '【最近新发生的对话】');
  const recent = data.buffer.slice(-30);
  for (const b of recent) lines.push(`${b.role === 'user' ? '[对方]' : '[你]'} ${clampText(b.text, 400)}`);

  let out = lines.join('\n');
  if (out.length > maxChars) {
    // 提示词太长时优先砍「模糊印象」，保住新对话和清楚记得的事
    const head = lines.slice(0, 7).join('\n');
    const tail = lines.slice(lines.indexOf('【最近新发生的对话】')).join('\n');
    out = `${head}\n\n【你只剩模糊印象的事】\n（略，共 ${data.faint.length} 条）\n\n${tail}`;
  }
  if (out.length > maxChars) out = out.slice(0, maxChars);
  return out;
}

/** 从模型回复里抠出 JSON，容忍 ```json 包裹、前后废话。 */
export function parseCompression(text) {
  const raw = String(text ?? '').trim();
  let candidate = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  const start = candidate.indexOf('{');
  const end = candidate.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('回复里没有 JSON 对象');
  candidate = candidate.slice(start, end + 1);
  const obj = JSON.parse(candidate);
  if (typeof obj.portrait !== 'string') throw new Error('缺 portrait');
  if (!Array.isArray(obj.keep)) throw new Error('缺 keep 数组');
  if (!Array.isArray(obj.faint)) throw new Error('缺 faint 数组');
  return {
    portrait: clampText(obj.portrait, 900),
    keep: obj.keep
      .filter((x) => x && typeof x.text === 'string' && x.text.trim())
      .map((x) => ({
        text: clampText(x.text, 240),
        importance: Math.min(5, Math.max(1, Math.round(Number(x.importance) || 3))),
      })),
    faint: obj.faint
      .filter((x) => x && typeof x.hint === 'string' && x.hint.trim())
      .map((x) => ({ hint: clampText(x.hint, 120) })),
    drop: Array.isArray(obj.drop)
      ? obj.drop
        .filter((x) => x && typeof x.text === 'string' && x.text.trim())
        .map((x) => ({ text: clampText(x.text, 240), why: clampText(x.why, 160) }))
      : [],
    note: clampText(obj.note, 200),
  };
}

// ───────────────────────── 空记忆 ─────────────────────────
function blank(convId, userId = '') {
  return {
    version: 2,
    conversationId: convId,
    // 归属写进文件本身：就算 state.json 丢了、会话记录被删，也知道这份记忆是谁的
    userId: String(userId || ''),
    portrait: '',
    core: [],
    faint: [],
    buffer: [],
    stats: {
      userTurns: 0,
      lastCompressedTurn: 0,
      compressCount: 0,
      lastCompressedAt: 0,
      lastActivityAt: 0,
      lastError: '',
      lastNote: '',
      nextId: 1,
    },
  };
}

function repair(data, convId) {
  const d = data && typeof data === 'object' ? data : blank(convId);
  d.version = 2;
  d.conversationId = convId;
  d.userId = typeof d.userId === 'string' ? d.userId : '';
  d.portrait = typeof d.portrait === 'string' ? d.portrait : '';
  d.core = Array.isArray(d.core) ? d.core.filter((x) => x && typeof x.text === 'string') : [];
  d.faint = Array.isArray(d.faint) ? d.faint.filter((x) => x && typeof x.hint === 'string') : [];
  d.buffer = Array.isArray(d.buffer) ? d.buffer : [];
  const s = d.stats && typeof d.stats === 'object' ? d.stats : {};
  d.stats = {
    userTurns: Number(s.userTurns) || 0,
    lastCompressedTurn: Number(s.lastCompressedTurn) || 0,
    compressCount: Number(s.compressCount) || 0,
    lastCompressedAt: Number(s.lastCompressedAt) || 0,
    lastActivityAt: Number(s.lastActivityAt) || 0,
    lastError: String(s.lastError || ''),
    lastNote: String(s.lastNote || ''),
    nextId: Math.max(
      Number(s.nextId) || 1,
      ...d.core.map((x) => (Number(x.id) || 0) + 1),
      ...d.faint.map((x) => (Number(x.id) || 0) + 1),
      1,
    ),
  };
  return d;
}

// ───────────────────────── 主类 ─────────────────────────
export class MemoryStore {
  /**
   * @param {object} opts { root, config, log, ask }
   *   ask(text, timeoutMs) → Promise<{ok:boolean, text:string, error?:string}>，
   *   由 bridge.mjs 提供：开一个独立 DSH 会话问一句，拿回文本。
   */
  constructor({ root, config = {}, log = () => {}, ask }) {
    this.root = root;
    this.cfg = { ...MEMORY_DEFAULTS, ...(config || {}) };
    this.dir = path.resolve(root, this.cfg.dir || MEMORY_DEFAULTS.dir);
    this.log = log;
    this.ask = ask;
    this.cache = new Map();
    this.saving = new Map();
    this.compressing = new Set();
    this.desired = new Set();
    // 每次清空 +1：压缩要跑几十秒，期间被人删了记忆，结果就不能再写回来
    this.generation = new Map();
  }

  fileFor(convId) {
    // convId 可能含中文 / 冒号 / 路径符号，一律 hash 成安全文件名
    const key = crypto.createHash('sha256').update(String(convId)).digest('hex').slice(0, 20);
    return path.join(this.dir, `${key}.json`);
  }

  /**
   * @param {Record<string,string>} owners conversationId → userId，由 bridge 从 state.json 传进来。
   *   老版本文件没有 userId：能对上现有会话的，启动时补写归属；
   *   对不上的（会话已删但记忆文件残留）保持「无归属」，之后谁都读不了，只能由管理员处理。
   */
  async init(owners = {}) {
    if (!this.cfg.enabled) return;
    await fs.mkdir(this.dir, { recursive: true });
    let files = [];
    try { files = await fs.readdir(this.dir); } catch { /* 首次运行 */ }
    let bound = 0;
    let orphan = 0;
    for (const f of files) {
      if (!f.endsWith('.json')) continue;
      try {
        const file = path.join(this.dir, f);
        const buf = await readBytes(file);
        if (!buf) throw new Error('读不到内容');
        const wasPlain = !isSealed(buf);
        const raw = JSON.parse(buf.toString('utf8'));
        const d = repair(raw, raw.conversationId || f.replace(/\.json$/, ''));
        // 顺手把老版本的明文文件改写成密文，一次启动全部迁完
        if (wasPlain || (!d.userId && owners[d.conversationId])) {
          if (!d.userId && owners[d.conversationId]) { d.userId = owners[d.conversationId]; bound += 1; }
          await writeJson(file, d);
        }
        if (!d.userId) orphan += 1;
        this.cache.set(d.conversationId, d);
      } catch (e) {
        this.log(`⚠ 记忆文件读不了：${f}（${e.message}），已跳过`);
      }
    }
    this.log(`长期记忆：${this.cfg.dir}（${this.cache.size} 份，${this.cfg.compressAfterUserTurns} 轮压缩一次` +
      (bound ? `，补写归属 ${bound} 份` : '') +
      (orphan ? `，⚠ ${orphan} 份无归属已隔离` : '') + '）');
  }

  /**
   * 取一份记忆。传入 userId 时会做归属校验：
   * 文件里记着的归属和当前用户不符 → 直接拒绝，绝不把别人的记忆喂给模型。
   * 老文件没有 userId 时，第一次由合法访问者补上（配合 bridge 侧的 ownsConversation）。
   */
  get(convId, userId = '') {
    if (!this.cfg.enabled) return null;
    if (!this.cache.has(convId)) this.cache.set(convId, blank(convId, userId));
    const d = this.cache.get(convId);
    // 无归属文件（会话已删但记忆残留）一律不许认领，避免「谁先来谁拿走」
    if (userId && !d.userId) {
      this.log(`⚠ 记忆 ${convId} 没有归属标记，已拒绝 ${userId} 访问（需管理员处理）`);
      return null;
    }
    if (userId && d.userId !== userId) {
      this.log(`⚠ 记忆归属不符：${convId} 属于 ${d.userId}，已拒绝 ${userId} 访问`);
      return null;
    }
    return d;
  }

  /** 原子落盘；同一份记忆的写操作串行，避免并发覆盖。 */
  async save(convId) {
    const d = this.get(convId);
    if (!d) return;
    const file = this.fileFor(convId);
    const prev = this.saving.get(convId) || Promise.resolve();
    const next = prev.catch(() => {}).then(async () => {
      await writeJson(file, d);
    }).catch((e) => this.log(`保存记忆失败 [${convId}]：${e.message}`));
    this.saving.set(convId, next);
    return next;
  }

  // ── 记录 ──
  recordUser(convId, text, userId = '') {
    const d = this.get(convId, userId);
    if (!d) return;
    const clean = clampText(text, 1000);
    if (!clean) return;
    d.buffer.push({ role: 'user', text: clean, ts: Date.now() });
    d.stats.userTurns += 1;
    d.stats.lastActivityAt = Date.now();
    if (d.buffer.length > Number(this.cfg.maxBufferItems)) {
      d.buffer.splice(0, d.buffer.length - Number(this.cfg.maxBufferItems));
      this.desired.add(convId);
    }
    if (d.stats.userTurns - d.stats.lastCompressedTurn >= Number(this.cfg.compressAfterUserTurns)) {
      this.desired.add(convId);
    }
    void this.save(convId);
  }

  recordAssistant(convId, text, userId = '') {
    const d = this.get(convId, userId);
    if (!d) return;
    const clean = clampText(text, 1000);
    if (!clean) return;
    d.buffer.push({ role: 'assistant', text: clean, ts: Date.now() });
    d.stats.lastActivityAt = Date.now();
    if (d.buffer.length > Number(this.cfg.maxBufferItems)) {
      d.buffer.splice(0, d.buffer.length - Number(this.cfg.maxBufferItems));
      this.desired.add(convId);
    }
    void this.save(convId);
  }

  // ── 注入 ──
  /**
   * 生成塞进 prompt 的记忆段落。
   * core 全给；faint 只挑「和这句话有关」+「最近」的几条，避免每轮塞一大坨。
   * @param {string} userText 当前用户这句话，用于唤起淡印象
   */
  promptBlock(convId, userText = '', userId = '') {
    const d = this.get(convId, userId);
    if (!d || (!d.portrait && !d.core.length && !d.faint.length)) return '';

    const blocks = [];
    const solid = [];
    if (d.portrait) solid.push(`关于对方：${clampText(d.portrait, Number(this.cfg.portraitMaxChars))}`);
    for (const f of d.core.slice(0, Number(this.cfg.maxCoreFacts))) solid.push(`- ${f.text}`);
    if (solid.length) {
      blocks.push('【你一直记得的事】\n（这些是你长期记得的、关于对方的事，不是他刚说的话。不用复述，自然用得上就用。）\n' + solid.join('\n'));
    }

    if (d.faint.length) {
      const scored = d.faint.map((f, i) => ({ f, i, score: similarity(userText, f.hint) }));
      const related = scored.filter((x) => x.score > 0.08).sort((a, b) => b.score - a.score)
        .slice(0, Number(this.cfg.faintRecallTopK));
      const picked = new Set(related.map((x) => x.i));
      const recent = scored.slice(-Number(this.cfg.faintRecentTopK));
      for (const x of recent) picked.add(x.i);
      const chosen = [...picked].sort((a, b) => a - b).map((i) => d.faint[i]);
      const lines = chosen.map((f) => `- ${f.hint}`);
      if (d.faint.length > chosen.length) lines.push(`- （另外还有 ${d.faint.length - chosen.length} 件零碎小事，印象很淡）`);
      blocks.push('【印象里还有这些】\n（只是模糊印象，聊到了可以自然提起，但别当成确凿事实，更别一条条背出来。）\n' + lines.join('\n'));
    }

    let out = blocks.join('\n\n');
    const cap = Number(this.cfg.promptMaxChars);
    if (out.length > cap) out = out.slice(0, cap) + '\n（记忆太长，后面略）';
    return out;
  }

  // ── 压缩 ──
  needsCompress(convId) {
    const d = this.get(convId);
    if (!d || !d.buffer.length || this.compressing.has(convId)) return false;
    if (this.desired.has(convId)) return true;
    const age = Date.now() - (d.stats.lastCompressedAt || d.stats.lastActivityAt || 0);
    return age > Number(this.cfg.compressMaxAgeMs) && d.buffer.length >= 2;
  }

  isIdle(convId) {
    const d = this.get(convId);
    if (!d) return true;
    return Date.now() - (d.stats.lastActivityAt || 0) >= Number(this.cfg.compressIdleMs);
  }

  /**
   * 跑一次压缩。失败不清 buffer，下次还能重试。
   * @returns {Promise<boolean>} 是否成功
   */
  async compress(convId, { force = false } = {}) {
    if (!this.cfg.enabled || !this.ask) return false;
    if (this.compressing.has(convId)) return false;
    const d = this.get(convId);
    if (!d || (!d.buffer.length && !force)) return false;
    if (!force && !this.isIdle(convId)) return false;

    this.compressing.add(convId);
    const gen = this.generation.get(convId) || 0;
    const snapshot = JSON.parse(JSON.stringify(d));   // 压缩期间聊天继续，别锁住主流程
    try {
      const prompt = buildCompressPrompt(snapshot, Number(this.cfg.promptMaxChars));
      const res = await this.ask(prompt, Number(this.cfg.compressTimeoutMs));
      if (!res?.ok || !res.text?.trim()) throw new Error(res?.error || '模型没有返回内容');
      const parsed = parseCompression(res.text);

      // 她明确说「记错了」的，尊重她，不再兜底找回；其余 core 若被手滑漏写，自动补回。
      const dropped = (text) => parsed.drop.some(
        (d) => normalize(d.text) === normalize(text) || looksLikeRewrite(d.text, text),
      );
      const keepTexts = parsed.keep.map((x) => x.text).filter((t) => !dropped(t));
      let restored = 0;
      let removed = 0;
      for (const old of snapshot.core) {
        if (dropped(old.text)) { removed += 1; continue; }
        const stillThere = keepTexts.some((t) => normalize(t) === normalize(old.text));
        const rewritten = keepTexts.some((t) => looksLikeRewrite(old.text, t));
        if (!stillThere && !rewritten) {
          keepTexts.push(old.text);
          parsed.keep.push({ text: old.text, importance: old.importance || 5 });
          restored += 1;
        }
      }
      // 只记数量，不把记忆原文 / 纠正原因写进日志（日志是明文且会被控制台拉走）
      if (removed) this.log(`[${convId}] 她主动纠正了 ${removed} 条记错的事`);

      // faint 也要留印象：超上限时把最旧的几条合成一条线索，而不是直接删。
      let faint = parsed.faint.map((f) => ({ ...f }));
      const cap = Number(this.cfg.maxFaint);
      if (faint.length > cap) {
        const dropped = faint.splice(0, faint.length - cap + 1);
        const hints = dropped.slice(0, 6).map((f) => f.hint.replace(/[。！？.!?]$/, '')).join('、');
        faint.unshift({ hint: `更早还零碎聊过 ${dropped.length} 件小事，像${hints}之类，细节已经模糊了` });
      }

      // 压缩跑了一分钟，这期间用户可能点了「清空」。那就别把旧内容写回来。
      if ((this.generation.get(convId) || 0) !== gen) {
        this.log(`[${convId}] 压缩期间记忆已被清空，丢弃本次整理结果`);
        return false;
      }
      const now = Date.now();
      const d2 = this.get(convId);
      const existingByText = new Map(d2.core.map((f) => [normalize(f.text), f]));
      d2.portrait = parsed.portrait || d2.portrait;
      d2.core = keepTexts.slice(0, Number(this.cfg.maxCoreFacts)).map((text) => {
        const old = existingByText.get(normalize(text));
        const meta = parsed.keep.find((x) => x.text === text);
        return {
          id: old?.id ?? d2.stats.nextId++,
          text,
          importance: meta?.importance ?? old?.importance ?? 3,
          createdAt: old?.createdAt ?? now,
          updatedAt: now,
        };
      });
      const oldFaintByHint = new Map(d2.faint.map((f) => [normalize(f.hint), f]));
      d2.faint = faint.map((f) => {
        const old = oldFaintByHint.get(normalize(f.hint));
        return { id: old?.id ?? d2.stats.nextId++, hint: f.hint, createdAt: old?.createdAt ?? now };
      });

      // 只清掉这次真的喂给模型的片段，压缩期间新来的话留着下次处理
      const consumed = snapshot.buffer.length;
      d2.buffer = d2.buffer.slice(consumed);
      d2.stats.lastCompressedTurn = snapshot.stats.userTurns;
      d2.stats.lastCompressedAt = now;
      d2.stats.compressCount += 1;
      d2.stats.lastError = '';
      d2.stats.lastNote = parsed.note || '';
      // 压缩期间又来了新消息的话，别把「待压缩」标记清掉
      if (!d2.buffer.length) this.desired.delete(convId);
      await this.save(convId);
      this.log(`[${convId}] 记忆压缩完成：core ${d2.core.length} 条 / 淡印象 ${d2.faint.length} 条` +
        (restored ? `（兜底找回 ${restored} 条重要事实）` : '') +
        (removed ? `（纠正 ${removed} 条）` : ''));
      return true;
    } catch (e) {
      const d2 = this.get(convId);
      d2.stats.lastError = e.message;
      void this.save(convId);
      this.log(`[${convId}] 记忆压缩失败（buffer 保留，稍后重试）：${e.message}`);
      return false;
    } finally {
      this.compressing.delete(convId);
    }
  }

  /** 定时调用：挑空闲的、需要压缩的记忆，一次只跑一份，别跟聊天抢 DSH。 */
  async tick(isBusy = () => false) {
    if (!this.cfg.enabled || this.compressing.size) return;
    for (const convId of this.cache.keys()) {
      if (!this.needsCompress(convId) || !this.isIdle(convId) || isBusy(convId)) continue;
      await this.compress(convId);
      return;
    }
  }

  /** 给控制台看：不含对话原文，只有记忆概况。没记忆就返回 null，不凭空造一份。 */
  describe(convId) {
    if (!this.cache.has(convId)) return null;
    const d = this.get(convId);
    if (!d) return null;
    return {
      conversationId: convId,
      portrait: d.portrait,
      core: d.core.map((f) => ({ id: f.id, text: f.text, importance: f.importance })),
      faintCount: d.faint.length,
      faintSample: d.faint.slice(-8).map((f) => f.hint),
      bufferCount: d.buffer.length,
      stats: { ...d.stats },
    };
  }

  list() {
    return [...this.cache.keys()];
  }

  async clear(convId) {
    this.generation.set(convId, (this.generation.get(convId) || 0) + 1);
    this.cache.delete(convId);
    this.desired.delete(convId);
    try { await fs.unlink(this.fileFor(convId)); } catch { /* 本来就没有 */ }
  }

  /**
   * 撤销用户时，把他名下的记忆一次清干净 —— 包括「会话记录已删、记忆文件还留着」的孤儿文件。
   * 老文件没有 userId 时，退回按 conversationId 前缀判断归属。
   */
  async clearByUser(userId) {
    let n = 0;
    for (const [cid, d] of [...this.cache]) {
      const byField = d.userId === userId;
      const byPrefix = !d.userId && (cid === userId || cid.startsWith(`${userId}:`) || cid.startsWith(`${userId}-`));
      if (byField || byPrefix) { await this.clear(cid); n += 1; }
    }
    return n;
  }

  /** 手动塞一条重要事实（控制台 / 用户自己补充用）。 */
  async pin(convId, text) {
    const d = this.get(convId);
    const clean = clampText(text, 240);
    if (!clean) return null;
    const item = { id: d.stats.nextId++, text: clean, importance: 5, createdAt: Date.now(), updatedAt: Date.now() };
    d.core.push(item);
    d.stats.lastActivityAt = Date.now();
    await this.save(convId);
    return item;
  }

  async unpin(convId, id) {
    const d = this.get(convId);
    const before = d.core.length;
    d.core = d.core.filter((f) => Number(f.id) !== Number(id));
    await this.save(convId);
    return before - d.core.length;
  }
}
