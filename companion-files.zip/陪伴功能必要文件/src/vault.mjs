// app-bridge / src/vault.mjs
//
// 落盘加密。目标很具体：把 state/ 目录整个拷走、同步到网盘、顺手发给人，
// 拿到的都只是一堆乱码 —— 而不是「聊天原文 + 记忆 + 图片 + 令牌」的明文 JSON。
//
// 设计取舍：
//   · 密钥不放项目目录，放 %APPDATA%/app-bridge/vault.key，避免「拷走文件夹就没密」；
//   · AES-256-GCM，每条记录自带随机 IV + 认证标签，改一个字节就解不开；
//   · 文件头 4 字节 BRV1 做标记，读的时候能认出「这是老的明文」并自动迁移；
//   · 密钥丢了不静默重建 —— 宁可报错退出，也不能用新密钥把旧数据盖成空。

import fsSync from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';

const MAGIC = Buffer.from('BRV1');
const MAGIC_LEN = 4;
const IV_LEN = 12;
const TAG_LEN = 16;
const HEADER_LEN = MAGIC_LEN + IV_LEN + TAG_LEN;

let KEY = null;
let KEY_PATH = '';

/** 密钥文件位置：项目外的用户目录，跟着 Windows 账户走。 */
export function keyLocation() {
  if (KEY_PATH) return KEY_PATH;
  const base = process.env.APPDATA
    || (process.platform === 'darwin'
      ? path.join(os.homedir(), 'Library', 'Application Support')
      : path.join(os.homedir(), '.config'));
  KEY_PATH = path.join(base, 'app-bridge', 'vault.key');
  return KEY_PATH;
}

/**
 * 初始化密钥。
 *
 * @param {object} opts
 * @param {string[]} [opts.probeFiles] 启动时用来判断「没有密钥但已有密文」的文件列表
 * @returns {{ created: boolean, keyPath: string }}
 */
export function initVault(opts = {}) {
  const file = keyLocation();
  const probe = (opts.probeFiles || []).filter(Boolean);

  let exists = fsSync.existsSync(file);
  if (!exists) {
    // 密钥没了但数据还在：绝不能新建一把把旧密文盖掉，直接让上层停下来。
    const orphan = probe.find((p) => {
      try {
        const fd = fsSync.openSync(p, 'r');
        const head = Buffer.alloc(MAGIC_LEN);
        fsSync.readSync(fd, head, 0, MAGIC_LEN, 0);
        fsSync.closeSync(fd);
        return head.equals(MAGIC);
      } catch { return false; }
    });
    if (orphan) {
      throw new Error(
        `找不到解密密钥（${file}），但 ${path.basename(orphan)} 是加密数据。\n`
        + `    请找回原来的 vault.key 放回该位置；确认数据不要了，就删掉 state 目录重新开始。`,
      );
    }
    fsSync.mkdirSync(path.dirname(file), { recursive: true });
    const fresh = crypto.randomBytes(32);
    fsSync.writeFileSync(file, `${fresh.toString('base64')}\n`, { encoding: 'utf8', mode: 0o600 });
    KEY = fresh;
    return { created: true, keyPath: file };
  }

  let text = '';
  try { text = fsSync.readFileSync(file, 'utf8').trim(); } catch (e) {
    throw new Error(`密钥文件读不了（${file}）：${e.message}`);
  }
  const buf = Buffer.from(text, 'base64');
  if (buf.length !== 32) {
    throw new Error(`密钥文件内容不对（${file}）：需要 32 字节，实际 ${buf.length} 字节`);
  }
  KEY = buf;
  return { created: false, keyPath: file };
}

function requireKey() {
  if (!KEY) throw new Error('vault 未初始化：请先调用 initVault()');
  return KEY;
}

/** 这段字节是不是 BRV1 密文。 */
export function isSealed(buf) {
  return Buffer.isBuffer(buf) && buf.length >= HEADER_LEN && buf.subarray(0, MAGIC_LEN).equals(MAGIC);
}

export function seal(plain) {
  const key = requireKey();
  const iv = crypto.randomBytes(IV_LEN);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const body = Buffer.concat([cipher.update(plain), cipher.final()]);
  return Buffer.concat([MAGIC, iv, cipher.getAuthTag(), body]);
}

export function unseal(sealed) {
  const key = requireKey();
  if (!isSealed(sealed)) return sealed;      // 老明文，原样返回，交给上层迁移
  const iv = sealed.subarray(MAGIC_LEN, MAGIC_LEN + IV_LEN);
  const tag = sealed.subarray(MAGIC_LEN + IV_LEN, HEADER_LEN);
  const body = sealed.subarray(HEADER_LEN);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(body), decipher.final()]);
}

/** 读文件 → 明文 Buffer。文件不存在返回 null。 */
export async function readBytes(file) {
  let raw;
  try { raw = await fs.readFile(file); } catch { return null; }
  try { return unseal(raw); }
  catch (e) {
    throw new Error(`${path.basename(file)} 解密失败（密钥不对或文件损坏）：${e.message}`);
  }
}

/** 明文 Buffer → 原子写入（先 tmp 再 rename）。 */
export async function writeBytes(file, plain) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  await fs.writeFile(tmp, seal(plain));
  await fs.rename(tmp, file);
}

/** 读 JSON：能读密的，也认老的明文。坏了返回 fallback。 */
export async function readJson(file, fallback = null) {
  const buf = await readBytes(file);
  if (!buf) return fallback;
  try { return JSON.parse(buf.toString('utf8')); } catch { return fallback; }
}

export async function writeJson(file, obj) {
  await writeBytes(file, Buffer.from(JSON.stringify(obj, null, 2), 'utf8'));
}

/** 同步版，给启动阶段用。 */
export function readJsonSync(file, fallback = null) {
  let raw;
  try { raw = fsSync.readFileSync(file); } catch { return fallback; }
  try { return JSON.parse(unseal(raw).toString('utf8')); } catch { return fallback; }
}
