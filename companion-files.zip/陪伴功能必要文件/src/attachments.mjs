// app-bridge / src/attachments.mjs
//
// 聊天里的图片与文件。App 把选中的内容用 base64 随 /v1/inbox 一起发过来，
// 桥接落盘到 state/uploads/，再把「元信息」放进 outbox 让 App 能显示 / 下载。
//
// 图片额外走一条路：DSH 的 session.prompt 支持 { type:'image', mediaType, data }，
// 所以图片会真的作为视觉内容喂给模型，她能看见 —— 不是只存个附件名。
// 其它文件 DSH 没有对应 content block，只能把文件名/大小作为文字告诉她。

import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { readBytes, writeBytes, readJson, writeJson, isSealed } from './vault.mjs';

/** DSH 接受的图片格式（见 dsh-client-connection 的 promptContentPartSchema）。 */
export const IMAGE_MIMES = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;   // DSH 单图上限 5MB
const MAX_FILE_BYTES = 8 * 1024 * 1024;    // 普通文件放宽到 8MB
const MAX_ATTACHMENTS = 12;

const convHash = (convId) =>
  crypto.createHash('sha256').update(String(convId)).digest('hex').slice(0, 20);

function safeName(raw, fallback) {
  const name = String(raw || '').replace(/[\\/\r\n\t]/g, '_').trim().slice(0, 120);
  return name || fallback;
}

/** 给模型看的附件说明（不含 base64）。只列「没法作为视觉内容喂进去」的那些。 */
export function describeForModel(attachments) {
  if (!attachments.length) return '';
  const lines = attachments.map((a) => {
    const size = a.size > 1024 * 1024
      ? `${(a.size / 1024 / 1024).toFixed(1)} MB`
      : `${Math.max(1, Math.round(a.size / 1024))} KB`;
    return `- ${a.kind === 'image' ? '图片' : '文件'}：${a.name}（${size}）`;
  });
  return `\n\n（对方还发来了这些附件。你现在只看到名字，读不到里面的内容，别假装看过：\n${lines.join('\n')}）`;
}

export class AttachmentStore {
  constructor({ root, log = () => {} }) {
    this.root = path.resolve(root, 'state', 'uploads');
    this.log = log;
  }

  async init() {
    await fs.mkdir(this.root, { recursive: true });
    // 老版本的附件是明文落在 uploads 里的，启动时逐个转成密文
    let files = [];
    try { files = await fs.readdir(this.root); } catch { return; }
    let sealed = 0;
    for (const f of files) {
      if (!f.endsWith('.bin') && !f.endsWith('.json')) continue;
      const p = path.join(this.root, f);
      try {
        const raw = await fs.readFile(p);
        if (isSealed(raw)) continue;
        await writeBytes(p, raw);
        sealed += 1;
      } catch (e) {
        this.log(`⚠ 附件加密失败：${f}（${e.message}）`);
      }
    }
    if (sealed) this.log(`附件加密：${sealed} 个历史文件已转为密文`);
  }

  /**
   * 落盘一组附件，返回可放进 outbox 的元信息。
   * imageData 只在内存中用于本次 DSH prompt，绝不写进 outbox 或返回给别的接口。
   */
  async store(convId, items) {
    if (!Array.isArray(items) || !items.length) return [];
    await fs.mkdir(this.root, { recursive: true });
    const out = [];
    for (const raw of items.slice(0, MAX_ATTACHMENTS)) {
      if (!raw || typeof raw !== 'object') continue;
      const kind = raw.kind === 'image' ? 'image' : 'file';
      const mime = String(raw.mime || (kind === 'image' ? 'image/jpeg' : 'application/octet-stream'))
        .slice(0, 100).toLowerCase();
      let data = String(raw.data || '');
      const comma = data.indexOf(',');
      if (data.startsWith('data:') && comma > 0) data = data.slice(comma + 1); // 容忍 data: URL 前缀
      if (!data) continue;
      let bytes;
      try { bytes = Buffer.from(data, 'base64'); } catch { continue; }
      if (!bytes.length) continue;
      const cap = kind === 'image' ? MAX_IMAGE_BYTES : MAX_FILE_BYTES;
      if (bytes.length > cap) {
        this.log(`附件超限已跳过：${raw.name || '?'}（${bytes.length} 字节 > ${cap}）`);
        continue;
      }

      const id = crypto.randomUUID();
      const key = `${convHash(convId)}_${id}`;
      const name = safeName(raw.name, kind === 'image' ? '图片' : '文件');
      const meta = {
        id, kind, name, mime, size: bytes.length,
        url: `/v1/attachment/${id}`,
      };
      // 附件本体和元信息都加密：拷走 uploads 目录只剩乱码
      await writeBytes(path.join(this.root, `${key}.bin`), bytes);
      await writeJson(path.join(this.root, `${key}.json`), meta);
      // 视觉内容：只有 DSH 认得的图片格式才真的喂给模型
      if (kind === 'image' && IMAGE_MIMES.has(mime)) {
        meta.imageData = data;
      }
      out.push(meta);
    }
    return out;
  }

  /** 下载：必须同时给出 conversationId，由调用方先做归属校验。 */
  async open(convId, id) {
    if (!/^[A-Za-z0-9-]{36}$/.test(String(id || ''))) return null;
    const key = `${convHash(convId)}_${id}`;
    try {
      const meta = await readJson(path.join(this.root, `${key}.json`), null);
      const bytes = await readBytes(path.join(this.root, `${key}.bin`));
      if (!meta || !bytes) return null;
      return { ...meta, bytes };
    } catch {
      return null;
    }
  }

  /** 删会话 / 撤销用户时，把它名下的附件一起清掉。 */
  async clearConversation(convId) {
    const prefix = `${convHash(convId)}_`;
    let files = [];
    try { files = await fs.readdir(this.root); } catch { return 0; }
    let n = 0;
    for (const f of files) {
      if (!f.startsWith(prefix)) continue;
      try { await fs.unlink(path.join(this.root, f)); n += 1; } catch { /* 已删 */ }
    }
    return n;
  }
}

/**
 * 把附件做成 DSH 的 content 数组。
 *
 * visionEnabled=false（默认）：所有附件都只以文字说明出现。当前师大网关的
 * deepseek-v4-flash 不支持图片输入，硬塞 image block 会被 DSH 以
 * `session/attachment-invalid` 拒绝，整条消息就没回复了。
 * 以后换了支持视觉的模型，把 config.dsh.vision 改成 true 即可真的看图。
 */
export function buildPromptContent(text, attachments, visionEnabled = false) {
  const visual = visionEnabled
    ? attachments.filter((a) => a.kind === 'image' && a.imageData && IMAGE_MIMES.has(a.mime))
    : [];
  const noted = visionEnabled ? attachments.filter((a) => !visual.includes(a)) : attachments;
  const content = [{ type: 'text', text: text + describeForModel(noted) }];
  for (const a of visual) {
    content.push({ type: 'image', mediaType: a.mime, data: a.imageData, name: a.name });
  }
  return content;
}
