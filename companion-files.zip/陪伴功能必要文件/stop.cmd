@echo off
setlocal
chcp 65001 >nul
title stop app-bridge
cd /d "%~dp0"

set "NODE="
where node >nul 2>nul && set "NODE=node"
if not defined NODE if exist "%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe" set "NODE=%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
if not defined NODE if exist "%PROGRAMFILES%\nodejs\node.exe" set "NODE=%PROGRAMFILES%\nodejs\node.exe"

if not defined NODE (
  echo   Node.js not found, cannot run stop script.
  pause
  exit /b 1
)

"%NODE%" "scripts\stop.mjs"

rem timeout breaks when stdin is redirected; ping is the portable pause
ping -n 3 127.0.0.1 >nul
endlocal
